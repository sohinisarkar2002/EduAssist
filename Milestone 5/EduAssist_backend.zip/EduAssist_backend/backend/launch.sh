#!/bin/bash

YELLOW='\033[1;33m'
RESET='\033[0m'

echo "Setting up the backend..."

# Create .venv and sync packages
uv sync

# Set up environment variables
if [[ ! -f .env ]]; then
    cp .env.example .env
    echo -e "  📝 Edit ${YELLOW}.env${RESET} and add your API/secret keys"
fi

# Activate virtual environment
if [[ -d ".venv/bin" ]]; then
    source .venv/bin/activate
else
    source .venv/Scripts/activate
fi

echo "Launching main application..."
uvicorn app.main:app --reload
