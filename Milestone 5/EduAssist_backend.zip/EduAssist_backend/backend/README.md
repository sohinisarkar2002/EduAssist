## Getting Started

1. Create a copy of `.env.example` and rename it to `.env`:

```bash
cp .env.example .env
```

2. Set up environment variables:

Create a free Database on [Neon](https://neon.tech) and set the `DATABASE_URL` environment variable in the format below:

```bash
DATABASE_URL=postgresql://user:password@host/dbname
```

Set the Gemini API key in the `GEMINI_API_KEY` environment variable

Generate the secret key and set it in the `SECRET_KEY` environment variable:

```bash
openssl rand -hex 32
```

3. Ensure [uv](https://docs.astral.sh/uv/getting-started/installation/) is installed:

```bash
command -v uv
```
```
uv self version
```

4. Run the server:

Start the backend server using `launch.sh` script:

```bash
./launch.sh
```