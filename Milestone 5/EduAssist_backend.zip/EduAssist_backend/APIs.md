### Authentication
- [X] POST `/auth/register`
- [X] POST `/auth/login`
- [X] POST `/auth/password-reset-request`
- [X] POST `/auth/reset-password`

### Knowledge Assistant
- [x] POST `/knowledge/documents`
- [x] GET  `/knowledge/documents`
- [ ] POST `/knowledge/conversations`
- [ ] GET  `/knowledge/conversations/{conversation_id}`
- [ ] POST `/knowledge/chat`

### Content Priority Tagger
- [X] GET  `/study-guides/video-info`
- [ ] POST `/study-guides`
- [X] GET  `/study-guides/`
- [X] GET  `/study-guides/{guide_id}`
- [X] DEL  `/study-guides/{guide_id}`
- [X] GET  `/study-guides/transcript/{video_id}`

### Workflow Automation
- [ ] POST `/workflow/workflow-requests/`
- [ ] GET  `/workflow/workflow-requests/`
- [ ] GET  `/workflow/workflow-requests/{id}`

### Assessment Generator
- [ ] POST `/assessments/`
- [ ] GET  `/assessments/`
- [ ] GET  `/assessments/{assessment_id}`
- [ ] DEL  `/assessments/{assessment_id}`
- [ ] GET  `/assessments/{assessment_id}/preview`
- [ ] POST `/assessments/{assessment_id}/attempts`
- [ ] POST `/assessments/attempts/{attempt_id}/submit`
- [ ] GET  `/assessments/my-attempts`

### Slide Deck Generator
- [ ] POST `/slide-decks/`
- [ ] GET  `/slide-decks/`
- [ ] GET  `/slide-decks/{deck_id}`
- [ ] PUT  `/slide-decks/{deck_id}/{slide_id}`

### Feedback
- [ ] POST `/feedback/`
- [ ] GET  `/feedback/`

### Default
- [X] POST `/token`
- [X] GET  `/courses`
- [X] POST `/courses`
- [X] GET  `/`
- [X] GET  `/health`
