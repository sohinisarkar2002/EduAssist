# EduAssist

An AI-powered teaching assistant platform designed to help educators create better content, engage students more effectively, and automate administrative tasks.

**Live Demo:** [https://eduassist-nine.vercel.app/](https://eduassist-nine.vercel.app/)

## About The Project

EduAssist is a modern web application that leverages AI technology to support educators and teaching assistants in their daily work. The platform provides features for generating study guides, creating assessments, producing slide decks, managing student feedback, and tagging content by priority.

### Key Features

- **Knowledge Assistant** - AI-powered answers to student questions with detailed explanations
- **Study Guide Generator** - Automatically generate comprehensive study guides from lecture content
- **Assessment Generator** - Create customized assessments with AI-generated questions
- **Slide Deck Creator** - Generate professional slide decks from lecture notes
- **Admin Workflow Agent** - Streamline administrative tasks with AI assistance
- **Content Priority Tagger** - Tag lecture content by priority with confusion heatmaps
- **Student Feedback System** - Collect and manage feedback from students
- **User Authentication** - Secure login, signup, and password reset functionality
- **Settings Management** - Profile, security, notification preferences, and app preferences

## Built With

### Frontend Stack
- **Next.js 14** - React framework with App Router
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Icon library
- **React Hooks** - State management
- **Next/Link** - Client-side navigation

### Design
- Minimalistic and professional UI
- Responsive design for all screen sizes
- Consistent color scheme and typography
- Accessibility-focused components

## Project Structure

```

/
├── frontend/
│   ├── app/
│   │   ├── page.tsx                    \# Landing page
│   │   ├── login/
│   │   │   └── page.tsx                \# Login page
│   │   ├── signup/
│   │   │   └── page.tsx                \# Signup page
│   │   ├── forgot-password/
│   │   │   └── page.tsx                \# Forgot password (multi-step)
│   │   ├── dashboard/
│   │   │   └── page.tsx                \# Main dashboard
│   │   ├── settings/
│   │   │   └── page.tsx                \# Settings page
│   │   ├── features/
│   │   │   ├── knowledge-assistant/
│   │   │   ├── study-guide-generator/
│   │   │   ├── assessment-generator/
│   │   │   ├── content-priority-tagger/
│   │   │   └── slide-deck-generator/
│   │   ├── layout.tsx                  \# Root layout
│   │   └── globals.css                 \# Global styles
│   ├── components/
│   │   └── AppLayout.tsx               \# Main app layout wrapper
│   ├── package.json
│   ├── tsconfig.json
│   ├── tailwind.config.js
│   ├── next.config.js
│   └── README.md
├── .gitignore
└── README.md

```

## Getting Started

### Prerequisites

- Node.js 18+ 
- npm, yarn, or pnpm package manager
- Git

### Installation

1. **Clone the repository**
```

git clone <repository-url>
cd eduassist

```

2. **Navigate to frontend directory**
```

cd frontend

```

3. **Install dependencies**
```

npm install

# or

yarn install

# or

pnpm install

```

4. **Set up environment variables**
Create a `.env.local` file in the `/frontend` directory:
```

NEXT_PUBLIC_API_URL=http://localhost:3000

# Add other environment variables as needed

```

5. **Run the development server**
```

npm run dev

# or

yarn dev

# or

pnpm dev

```

6. **Open your browser**
Navigate to [http://localhost:3000](http://localhost:3000) to see the application.

## Usage

### User Flows

#### Unauthenticated Users
1. Visit the landing page at `/`
2. Click "Get Started" button to navigate to `/login`
3. Sign in with credentials or create a new account at `/signup`
4. Reset password using `/forgot-password` if needed

#### Authenticated Users
1. Access the `/dashboard` to see available features
2. Navigate through main sidebar to access features:
   - Knowledge Assistant
   - Study Guide Generator
   - Assessment Generator
   - Content Priority Tagger
   - Slide Deck Creator
3. Access settings via profile dropdown in navbar
4. Use feature-specific child sidebars for sub-sections

### Feature Navigation

Each feature page includes:
- Main feature interface on the right
- Child sidebar with action tabs on the left
- Student feedback collection in dedicated tabs
- Mock/placeholder content for demonstration

## File Organization

### Pages
- **Landing Page** (`app/page.tsx`) - Public homepage with feature overview
- **Authentication Pages** - Login, signup, forgot password flows
- **Dashboard** (`app/dashboard/page.tsx`) - Main hub for authenticated users
- **Settings** (`app/settings/page.tsx`) - User preferences and account settings
- **Feature Pages** (`app/features/*/page.tsx`) - Individual feature implementations

### Components
- **AppLayout** (`components/AppLayout.tsx`) - Wrapper component with header, sidebar, and navigation

### Styling
- **Tailwind CSS** - All components use utility classes
- **Color Palette:**
  - Primary: `#0d141b` (Dark)
  - Secondary: `#4c739a` (Blue-gray)
  - Accent: `#1380ec` (Bright blue)
  - Borders: `#cfdbe7`, `#dbdbdb`
  - Background: `slate-50`, `neutral-50`

## Deployment

The project is deployed on **Vercel** at: [https://eduassist-nine.vercel.app/](https://eduassist-nine.vercel.app/)

### Deploy to Vercel

1. **Push to GitHub**
```

git add .
git commit -m "Initial commit"
git push origin main

```

2. **Connect to Vercel**
   - Visit [vercel.com](https://vercel.com)
   - Click "New Project"
   - Import the GitHub repository
   - Select `/frontend` as the root directory
   - Configure environment variables
   - Deploy

3. **Automatic Deployments**
   - Vercel automatically deploys on every push to main
   - Preview deployments for pull requests

## Development Workflow

### Running Tests
```

npm run test

# or

yarn test

```

### Building for Production
```

npm run build

# or

yarn build

```

### Starting Production Server
```

npm run start

# or

yarn start

```

### Linting
```

npm run lint

# or

yarn lint

```

## API Integration

The frontend is currently designed with mock data and placeholder content. To integrate with a backend API:

1. Replace mock data in feature components with API calls
2. Update environment variables for API endpoints
3. Add authentication token handling
4. Implement error handling and loading states

## Customization

### Colors
Edit `tailwind.config.js` to customize the color scheme:
```

theme: {
colors: {
// Custom colors
}
}

```

### Typography
Modify font sizes and weights in Tailwind configuration or individual components.

### Features
Add new features by creating new folders in `app/features/` following the existing pattern.

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## Contributing

Contributions are welcome! Please follow these steps:

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contact

For questions or support, please reach out to the development team or create an issue in the repository.

## Acknowledgments

- Built with [Next.js](https://nextjs.org/)
- Styled with [Tailwind CSS](https://tailwindcss.com/)
- Icons from [Lucide React](https://lucide.dev/)
- Deployed on [Vercel](https://vercel.com/)

[^10]: https://nextjs.org/docs

