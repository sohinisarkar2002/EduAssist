"use client";

import AppLayout from "@/components/AppLayout";
import { useEffect, useState, useRef } from "react";
import ReactMarkdown from "react-markdown";
import { Dialog, Transition } from "@headlessui/react";
import { Fragment } from "react";
import { X, Download, Eye, Clock } from "lucide-react";
import { pdf, Document, Page, Text, View, StyleSheet } from "@react-pdf/renderer";

type ActiveTab = "tagger" | "past" | "feedback";

export interface StudyGuideSegment {
  id?: number;
  title: string;
  start: number;
  end: number;
  summary: string;
}

export interface StudyGuide {
  id: number;
  youtube_url: string;
  video_id: string;
  video_title: string;
  video_duration: number;
  title: string;
  content: string;
  key_topics: string[];
  status: "PENDING" | "GENERATING" | "COMPLETED" | "FAILED";
  course_id?: number | null;
  created_by: number;
  created_at: string;
  segments: StudyGuideSegment[];
}

export interface StudyGuideListResponse {
  guides: StudyGuide[];
  total: number;
}

// Feedback interfaces
export interface Feedback {
  id: number;
  target_id: number;
  target_type: string;
  rating: number;
  aspect_ratings: Record<string, number>;
  comment: string;
  user_id: number;
  created_at: string;
}

// PDF Styles
const pdfStyles = StyleSheet.create({
  page: {
    padding: 40,
    fontFamily: "Helvetica",
    fontSize: 11,
    lineHeight: 1.6,
  },
  header: {
    marginBottom: 20,
    borderBottom: "1 solid #e2e8f0",
    paddingBottom: 15,
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 12,
    color: "#6b7280",
    marginBottom: 3,
  },
  meta: {
    fontSize: 10,
    color: "#9ca3af",
    marginTop: 5,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 14,
    fontWeight: "bold",
    marginBottom: 10,
    marginTop: 15,
  },
  content: {
    fontSize: 11,
    textAlign: "justify",
    marginBottom: 10,
    lineHeight: 1.5,
  },
  topicsList: {
    marginLeft: 10,
  },
  listItem: {
    marginBottom: 5,
    fontSize: 11,
  },
  segment: {
    border: "1 solid #d1d5db",
    padding: 8,
    marginBottom: 8,
    backgroundColor: "#f9fafb",
  },
  segmentTitle: {
    fontSize: 11,
    fontWeight: "bold",
    marginBottom: 3,
  },
  segmentTime: {
    fontSize: 9,
    color: "#6b7280",
    marginBottom: 3,
  },
  segmentSummary: {
    fontSize: 10,
  },
  pageNumber: {
    position: "absolute",
    bottom: 20,
    right: 40,
    fontSize: 9,
    color: "#9ca3af",
  },
});

// PDF Document Component
const StudyGuidePDF = ({ guide }: { guide: StudyGuide; }) => {
  const plainContent = guide.content
    .replace(/^#+\s/gm, "")
    .replace(/\*\*/g, "")
    .replace(/\*/g, "")
    .replace(/\n\n/g, "\n")
    .split("\n")
    .filter((line) => line.trim());

  return (
    <Document>
      <Page size="A4" style={pdfStyles.page}>
        <View style={pdfStyles.header}>
          <Text style={pdfStyles.title}>{guide.title}</Text>
          <Text style={pdfStyles.subtitle}>{guide.video_title}</Text>
          <Text style={pdfStyles.meta}>
            Duration: {Math.round(guide.video_duration)} seconds
          </Text>
          <Text style={pdfStyles.meta}>
            Created:{" "}
            {new Date(guide.created_at).toLocaleDateString("en-US", {
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </Text>
        </View>

        <View style={pdfStyles.section}>
          <Text style={pdfStyles.sectionTitle}>Summary</Text>
          {plainContent.slice(0, 10).map((line, idx) => (
            <Text key={idx} style={pdfStyles.content}>
              {line}
            </Text>
          ))}
        </View>

        {guide.key_topics.length > 0 && (
          <View style={pdfStyles.section}>
            <Text style={pdfStyles.sectionTitle}>Key Topics</Text>
            <View style={pdfStyles.topicsList}>
              {guide.key_topics.map((topic, idx) => (
                <Text key={idx} style={pdfStyles.listItem}>
                  • {topic}
                </Text>
              ))}
            </View>
          </View>
        )}

        {guide.segments.length > 0 && (
          <View style={pdfStyles.section}>
            <Text style={pdfStyles.sectionTitle}>Video Segments</Text>
            {guide.segments.map((seg, idx) => (
              <View key={seg.id ?? idx} style={pdfStyles.segment}>
                <Text style={pdfStyles.segmentTitle}>{seg.title}</Text>
                <Text style={pdfStyles.segmentTime}>
                  {seg.start}s – {seg.end}s
                </Text>
                <Text style={pdfStyles.segmentSummary}>{seg.summary}</Text>
              </View>
            ))}
          </View>
        )}

        <Text
          style={pdfStyles.pageNumber}
          render={({ pageNumber, totalPages }) =>
            `Page ${pageNumber} of ${totalPages}`
          }
        />
      </Page>
    </Document>
  );
};

export default function ContentTagger() {
  const [activeTab, setActiveTab] = useState<ActiveTab>("tagger");

  const API_BASE = process.env.NEXT_PUBLIC_API_URL;
  const token =
    typeof window !== "undefined" ? localStorage.getItem("access_token") : null;

  // States
  const [youtubeUrl, setYoutubeUrl] = useState("");
  const [videoInfo, setVideoInfo] = useState<any>(null);

  const [prioritySegments, setPrioritySegments] = useState<
    { start: number; end: number; priority: string; }[]
  >([]);

  const [guideId, setGuideId] = useState<number | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [guide, setGuide] = useState<StudyGuide | null>(null);

  const [loading, setLoading] = useState(false);

  // Past guides
  const [pastGuides, setPastGuides] = useState<StudyGuide[]>([]);
  const [pastGuidesTotal, setPastGuidesTotal] = useState<number>(0);
  const [pastGuidesLoading, setPastGuidesLoading] = useState(false);
  const [selectedPastGuide, setSelectedPastGuide] = useState<StudyGuide | null>(
    null
  );

  // Preview Modal
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  const [previewGuide, setPreviewGuide] = useState<StudyGuide | null>(null);
  const [previewLoading, setPreviewLoading] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  // YouTube Player state
  const [player, setPlayer] = useState<any>(null);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [segmentStart, setSegmentStart] = useState<number | null>(null);
  const [isPlayerReady, setIsPlayerReady] = useState(false);
  const playerRef = useRef<any>(null);

  // Feedback states
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [feedbackLoading, setFeedbackLoading] = useState(false);
  const [selectedRating, setSelectedRating] = useState<number>(0);
  const [feedbackComment, setFeedbackComment] = useState("");
  const [submittingFeedback, setSubmittingFeedback] = useState(false);

  // Helper to extract video ID from URL
  const extractVideoIdFromUrl = (url: string): string | null => {
    try {
      const u = new URL(url);
      if (u.hostname === "youtu.be") return u.pathname.slice(1);
      if (u.searchParams.get("v")) return u.searchParams.get("v");
      const parts = u.pathname.split("/");
      if (parts.includes("embed")) {
        return parts[parts.indexOf("embed") + 1];
      }
      return null;
    } catch {
      return null;
    }
  };

  // Load YouTube IFrame API
  useEffect(() => {
    if (typeof window === "undefined") return;

    if (!(window as any).YT) {
      const tag = document.createElement("script");
      tag.src = "https://www.youtube.com/iframe_api";
      const firstScriptTag = document.getElementsByTagName("script")[0];
      firstScriptTag?.parentNode?.insertBefore(tag, firstScriptTag);

      (window as any).onYouTubeIframeAPIReady = () => {
        console.log("YouTube IFrame API ready");
      };
    }
  }, []);

  // Initialize YouTube Player
  useEffect(() => {
    if (
      typeof window === "undefined" ||
      !(window as any).YT ||
      !playerRef.current
    )
      return;

    const videoId = extractVideoIdFromUrl(youtubeUrl);
    if (!videoId) return;

    const initPlayer = () => {
      const newPlayer = new (window as any).YT.Player(playerRef.current, {
        videoId: videoId,
        playerVars: {
          enablejsapi: 1,
          origin: window.location.origin,
        },
        events: {
          onReady: (event: any) => {
            setPlayer(event.target);
            setIsPlayerReady(true);
          },
        },
      });
    };

    if ((window as any).YT.Player) {
      initPlayer();
    }

    return () => {
      if (player) {
        player.destroy();
      }
    };
  }, [youtubeUrl]);

  // Poll current time from player
  useEffect(() => {
    if (!player || !isPlayerReady) return;

    const interval = setInterval(() => {
      try {
        const time = player.getCurrentTime();
        if (time !== undefined) {
          setCurrentTime(Math.floor(time));
        }
      } catch (err) {
        console.error("Error getting current time:", err);
      }
    }, 500);

    return () => clearInterval(interval);
  }, [player, isPlayerReady]);

  // Mark segment start
  const handleMarkStart = () => {
    if (currentTime !== null) {
      setSegmentStart(currentTime);
    }
  };

  // Mark segment end and add to list
  const handleMarkEnd = () => {
    if (segmentStart !== null && currentTime !== null) {
      const newSegment = {
        start: segmentStart,
        end: currentTime,
        priority: "medium",
      };
      setPrioritySegments((prev) => [...prev, newSegment]);
      setSegmentStart(null);
    }
  };

  // ------------------------------------------
  // FEEDBACK FUNCTIONS
  // ------------------------------------------
  const fetchFeedback = async () => {
    setFeedbackLoading(true);
    try {
      const url = new URL("/feedback/", API_BASE);
      url.searchParams.append("target_id", "1");
      url.searchParams.append("target_type", "study_guide");

      const res = await fetch(url.toString(), {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        console.error("Failed to fetch feedback", await res.text());
        setFeedbackLoading(false);
        return;
      }

      const data: Feedback[] = await res.json();
      setFeedbacks(data);
    } catch (err) {
      console.error("Error fetching feedback:", err);
    }
    setFeedbackLoading(false);
  };

  const submitFeedback = async () => {
    if (selectedRating === 0) {
      alert("Please select a rating");
      return;
    }

    if (!feedbackComment.trim()) {
      alert("Please provide a comment");
      return;
    }

    setSubmittingFeedback(true);
    try {
      const payload = {
        target_id: 1,
        target_type: "study_guide",
        rating: selectedRating,
        aspect_ratings: {},
        comment: feedbackComment,
      };

      const res = await fetch(`${API_BASE}/feedback/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        console.error("Failed to submit feedback", await res.text());
        alert("Failed to submit feedback");
        setSubmittingFeedback(false);
        return;
      }

      // Reset form
      setSelectedRating(0);
      setFeedbackComment("");

      // Refresh feedback list
      await fetchFeedback();

      alert("Feedback submitted successfully!");
    } catch (err) {
      console.error("Error submitting feedback:", err);
      alert("Error submitting feedback");
    }
    setSubmittingFeedback(false);
  };

  // Fetch feedback when tab changes
  useEffect(() => {
    if (activeTab === "feedback") {
      fetchFeedback();
    }
  }, [activeTab]);

  // ------------------------------------------
  // EXPORT TO PDF
  // ------------------------------------------
  const handleExportPDF = async (guideToExport: StudyGuide) => {
    setIsExporting(true);
    try {
      const pdfDocument = <StudyGuidePDF guide={guideToExport} />;
      const blob = await pdf(pdfDocument).toBlob();

      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = `study-guide-${guideToExport.id}.pdf`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error("PDF export failed:", err);
      alert("Failed to export PDF");
    } finally {
      setIsExporting(false);
    }
  };

  // ------------------------------------------
  // GET VIDEO INFO
  // ------------------------------------------
  const fetchVideoInfo = async () => {
    if (!youtubeUrl.trim()) return alert("Enter a YouTube URL");

    setLoading(true);
    try {
      const res = await fetch(
        `${API_BASE}/study-guides/video-info?url=${encodeURIComponent(
          youtubeUrl
        )}`,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      const text = await res.text();

      try {
        const parsed = JSON.parse(text);
        setVideoInfo(parsed);
      } catch {
        setVideoInfo({ raw: text });
      }
    } catch (err) {
      console.error(err);
      alert("Failed to fetch video info");
    }

    setLoading(false);
  };

  // ------------------------------------------
  // ADD PRIORITY SEGMENT
  // ------------------------------------------
  const addSegment = () => {
    setPrioritySegments((prev) => [
      ...prev,
      { start: 0, end: 60, priority: "medium" },
    ]);
  };

  const updateSegment = (index: number, field: string, value: any) => {
    const updated = [...prioritySegments];
    updated[index] = { ...updated[index], [field]: value };
    setPrioritySegments(updated);
  };

  const removeSegment = (index: number) => {
    setPrioritySegments((prev) => prev.filter((_, i) => i !== index));
  };

  // ------------------------------------------
  // CREATE STUDY GUIDE
  // ------------------------------------------
  const generateStudyGuide = async () => {
    if (!youtubeUrl.trim()) return alert("Enter a YouTube URL");

    setLoading(true);

    try {
      const body: any = {
        youtube_url: youtubeUrl,
        course_id: 0,
        title: videoInfo?.video_title || videoInfo?.title || "Study Guide",
        priority_segments: prioritySegments.map((s) => ({
          start: s.start,
          end: s.end,
          priority: s.priority.toLowerCase(),
        })),
      };

      const res = await fetch(`${API_BASE}/study-guides/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        console.error("Failed to create study guide", await res.text());
        alert("Failed to create study guide");
        setLoading(false);
        return;
      }

      const data: StudyGuide = await res.json();

      if (data.id) {
        setGuideId(data.id);
        setStatus(data.status);
        setGuide(null);
      } else {
        alert("Failed to create study guide");
      }
    } catch (err) {
      console.error(err);
      alert("API error");
    }

    setLoading(false);
  };

  // ------------------------------------------
  // POLLING GUIDE STATUS
  // ------------------------------------------
  useEffect(() => {
    if (!guideId) return;

    const poll = setInterval(async () => {
      try {
        const res = await fetch(`${API_BASE}/study-guides/${guideId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!res.ok) {
          console.error("Failed to fetch study guide status");
          return;
        }

        const data: StudyGuide = await res.json();
        setStatus(data.status);
        if (data.status === "COMPLETED") {
          setGuide(data);
          clearInterval(poll);
        }

        if (data.status === "FAILED") {
          clearInterval(poll);
          alert("Study guide generation failed.");
        }
      } catch (err) {
        console.error(err);
      }
    }, 3000);

    return () => clearInterval(poll);
  }, [guideId, API_BASE, token]);

  // ------------------------------------------
  // FETCH PAST GUIDES
  // ------------------------------------------
  const fetchPastGuides = async () => {
    if (!API_BASE) return;

    setPastGuidesLoading(true);
    try {
      const url = new URL("/study-guides/", API_BASE);

      const res = await fetch(url.toString(), {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        console.error("Failed to fetch past study guides", await res.text());
        setPastGuidesLoading(false);
        return;
      }

      const data: StudyGuideListResponse = await res.json();
      setPastGuides(data.guides);
      setPastGuidesTotal(data.total);
      if (data.guides.length > 0) {
        setSelectedPastGuide(data.guides[0]);
      } else {
        setSelectedPastGuide(null);
      }
    } catch (err) {
      console.error(err);
    }

    setPastGuidesLoading(false);
  };

  useEffect(() => {
    if (activeTab === "past") {
      fetchPastGuides();
    }
  }, [activeTab]);

  // ------------------------------------------
  // PREVIEW GUIDE BY ID
  // ------------------------------------------
  const openPreview = async (guideId: number) => {
    setPreviewLoading(true);
    setIsPreviewOpen(true);

    try {
      const res = await fetch(`${API_BASE}/study-guides/${guideId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) {
        alert("Failed to fetch study guide");
        setIsPreviewOpen(false);
        return;
      }

      const data: StudyGuide = await res.json();
      setPreviewGuide(data);
    } catch (err) {
      console.error(err);
      alert("Failed to load preview");
      setIsPreviewOpen(false);
    }

    setPreviewLoading(false);
  };

  const closePreview = () => {
    setIsPreviewOpen(false);
    setPreviewGuide(null);
  };

  // Helper to get YouTube embed URL
  const getYouTubeEmbedUrl = (videoId: string) => {
    return `https://www.youtube.com/embed/${videoId}`;
  };

  // Format time for display
  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // ------------------------------------------
  // RENDER
  // ------------------------------------------
  return (
    <AppLayout>
      <div className="flex flex-1">
        {/* SIDEBAR */}
        <div className="flex flex-col w-80 bg-slate-50 border-r border-slate-200 p-4">
          <h2 className="text-lg font-bold mb-4">Study Guides</h2>

          <button
            onClick={() => setActiveTab("tagger")}
            className={`px-3 py-2 rounded-lg mb-2 text-left transition ${activeTab === "tagger"
              ? "bg-blue-600 text-white"
              : "hover:bg-slate-100"
              }`}
          >
            Content Priority Tagger
          </button>

          <button
            onClick={() => setActiveTab("past")}
            className={`px-3 py-2 rounded-lg mb-2 text-left transition ${activeTab === "past"
              ? "bg-blue-600 text-white"
              : "hover:bg-slate-100"
              }`}
          >
            Past Study Guides
          </button>

          <button
            onClick={() => setActiveTab("feedback")}
            className={`px-3 py-2 rounded-lg text-left transition ${activeTab === "feedback"
              ? "bg-blue-600 text-white"
              : "hover:bg-slate-100"
              }`}
          >
            Collect Feedback
          </button>
        </div>

        {/* MAIN CONTENT */}
        <div className="flex-1 p-6 overflow-auto">
          {activeTab === "tagger" && (
            <>
              <div className="flex items-center justify-between mb-6">
                <h1 className="text-[28px] font-bold">
                  AI Study Guide Generator
                </h1>
                {loading && (
                  <span className="text-sm text-slate-500">Loading...</span>
                )}
              </div>

              {/* YOUTUBE INPUT */}
              <div className="mb-6">
                <p className="font-semibold mb-1">YouTube URL</p>
                <div className="flex gap-2">
                  <input
                    value={youtubeUrl}
                    onChange={(e) => setYoutubeUrl(e.target.value)}
                    placeholder="Paste YouTube link"
                    className="border border-slate-300 p-3 rounded-lg flex-1 focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    onClick={fetchVideoInfo}
                    className="px-4 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-slate-800"
                  >
                    Fetch Info
                  </button>
                </div>
              </div>

              {/* VIDEO INFO DISPLAY */}
              {videoInfo && (
                <div className="border border-slate-200 p-4 rounded-lg bg-slate-50 mb-6">
                  <p className="font-bold text-lg mb-2">
                    {videoInfo.video_title ||
                      videoInfo.title ||
                      videoInfo.raw ||
                      "Video Info"}
                  </p>

                  {videoInfo.video_duration && (
                    <p className="text-sm text-slate-600 mb-2">
                      Duration: {videoInfo.video_duration}s
                    </p>
                  )}

                  {youtubeUrl && (
                    <a
                      href={youtubeUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-sm text-blue-600 underline inline-block"
                    >
                      Open video in YouTube
                    </a>
                  )}
                </div>
              )}

              {/* VIDEO PREVIEW WITH CONTROLS */}
              {youtubeUrl && extractVideoIdFromUrl(youtubeUrl) && (
                <div className="mb-6">
                  <div className="border border-slate-200 rounded-lg overflow-hidden">
                    <div
                      ref={playerRef}
                      className="w-full"
                      style={{ aspectRatio: "16/9" }}
                    />
                  </div>

                  {/* Segment Marking Controls */}
                  <div className="mt-4 border border-slate-200 rounded-lg p-4 bg-slate-50">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-slate-600" />
                        <span className="text-sm font-medium">
                          Current Time: {formatTime(currentTime)}
                        </span>
                      </div>
                      {segmentStart !== null && (
                        <span className="text-xs text-blue-600 font-medium">
                          Start marked at {formatTime(segmentStart)}
                        </span>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={handleMarkStart}
                        disabled={!isPlayerReady}
                        className="flex-1 px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white rounded-lg text-sm font-medium"
                      >
                        Mark Start
                      </button>
                      <button
                        onClick={handleMarkEnd}
                        disabled={!isPlayerReady || segmentStart === null}
                        className="flex-1 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:bg-slate-300 text-white rounded-lg text-sm font-medium"
                      >
                        Mark End & Add Segment
                      </button>
                    </div>

                    <p className="text-xs text-slate-500 mt-2">
                      Play the video, click "Mark Start" at the beginning of an
                      important section, then click "Mark End & Add Segment"
                      when it ends.
                    </p>
                  </div>
                </div>
              )}

              {/* PRIORITY SEGMENTS */}
              <div className="mb-4">
                <div className="flex items-center justify-between mb-2">
                  <h2 className="text-xl font-bold">Priority Segments</h2>
                  <button
                    onClick={addSegment}
                    className="px-3 py-2 bg-slate-200 hover:bg-slate-300 rounded-lg text-sm font-medium"
                  >
                    + Add Manual Segment
                  </button>
                </div>
                <p className="text-sm text-slate-600 mb-3">
                  Use the video player above to mark segments, or manually add
                  time ranges below.
                </p>
              </div>

              {prioritySegments.length === 0 && (
                <p className="text-sm text-slate-500 mb-4">
                  No segments added yet. Use the video controls to mark
                  segments or add them manually.
                </p>
              )}

              {prioritySegments.map((seg, index) => (
                <div
                  key={index}
                  className="flex items-center gap-2 mb-3 bg-slate-50 border border-slate-200 rounded-lg p-3"
                >
                  <div className="flex flex-col">
                    <label className="text-xs text-slate-500 mb-1">
                      Start (s)
                    </label>
                    <input
                      type="number"
                      value={seg.start}
                      onChange={(e) =>
                        updateSegment(index, "start", Number(e.target.value))
                      }
                      className="border border-slate-300 p-2 rounded w-24 text-sm"
                      placeholder="Start"
                      min={0}
                    />
                  </div>
                  <div className="flex flex-col">
                    <label className="text-xs text-slate-500 mb-1">
                      End (s)
                    </label>
                    <input
                      type="number"
                      value={seg.end}
                      onChange={(e) =>
                        updateSegment(index, "end", Number(e.target.value))
                      }
                      className="border border-slate-300 p-2 rounded w-24 text-sm"
                      placeholder="End"
                      min={0}
                    />
                  </div>

                  <div className="flex flex-col">
                    <label className="text-xs text-slate-500 mb-1">
                      Priority
                    </label>
                    <select
                      value={seg.priority}
                      onChange={(e) =>
                        updateSegment(index, "priority", e.target.value)
                      }
                      className="border border-slate-300 p-2 rounded text-sm"
                    >
                      <option value="low">Low</option>
                      <option value="medium">Medium</option>
                      <option value="high">High</option>
                    </select>
                  </div>

                  <div className="flex items-center ml-auto gap-2">
                    <span className="text-xs text-slate-500">
                      {formatTime(seg.start)} - {formatTime(seg.end)}
                    </span>
                    <button
                      onClick={() => removeSegment(index)}
                      className="text-xs text-red-600 hover:underline"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              ))}

              {/* GENERATE BUTTON */}
              <div className="mt-4">
                <button
                  onClick={generateStudyGuide}
                  disabled={loading || prioritySegments.length === 0}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white rounded-lg text-sm font-medium"
                >
                  {loading ? "Generating..." : "Generate Study Guide"}
                </button>
                {prioritySegments.length === 0 && (
                  <p className="text-xs text-amber-600 mt-2">
                    Add at least one segment to generate a study guide
                  </p>
                )}
              </div>

              {/* STATUS */}
              {guideId && (
                <p className="mt-4 text-sm">
                  Status:{" "}
                  <strong
                    className={
                      status === "COMPLETED"
                        ? "text-green-600"
                        : status === "FAILED"
                          ? "text-red-600"
                          : "text-amber-600"
                    }
                  >
                    {status}
                  </strong>
                </p>
              )}

              {/* GUIDE DISPLAY */}
              {guide && (
                <div className="mt-8">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-2xl font-bold">
                      Generated Study Guide
                    </h2>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => handleExportPDF(guide)}
                        disabled={isExporting}
                        className="flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white rounded-lg text-sm font-medium"
                      >
                        <Download className="w-4 h-4" />
                        {isExporting ? "Exporting..." : "Export PDF"}
                      </button>
                      <button
                        onClick={() => openPreview(guide.id)}
                        className="flex items-center gap-2 px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg text-sm font-medium"
                      >
                        <Eye className="w-4 h-4" />
                        Preview
                      </button>
                    </div>
                  </div>

                  <p className="text-sm text-slate-500 mb-4">
                    {guide.video_title} • {Math.round(guide.video_duration)}{" "}
                    seconds
                  </p>

                  {/* YouTube Video Embed */}
                  {guide.video_id && (
                    <div className="mb-6">
                      <iframe
                        width="100%"
                        height="400"
                        src={getYouTubeEmbedUrl(guide.video_id)}
                        title={guide.video_title}
                        frameBorder="0"
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                        className="rounded-lg"
                      ></iframe>
                    </div>
                  )}

                  <h3 className="text-lg font-semibold mt-4 mb-2">Summary</h3>
                  <div className="border border-slate-200 rounded-lg p-4 bg-white prose prose-sm max-w-none">
                    <ReactMarkdown>{guide.content}</ReactMarkdown>
                  </div>

                  <h3 className="text-lg font-semibold mt-6 mb-2">
                    Key Topics
                  </h3>
                  <ul className="list-disc ml-6 text-sm space-y-1">
                    {guide.key_topics.map((t, i) => (
                      <li key={i}>{t}</li>
                    ))}
                  </ul>

                  <h3 className="text-lg font-semibold mt-6 mb-2">Segments</h3>
                  {guide.segments.length === 0 && (
                    <p className="text-sm text-slate-500">
                      No detailed segments available for this guide.
                    </p>
                  )}
                  {guide.segments.map((seg, i) => (
                    <div
                      className="border border-slate-200 bg-slate-50 p-3 my-2 rounded"
                      key={i}
                    >
                      <p className="font-semibold text-sm">{seg.title}</p>
                      <p className="text-xs text-slate-600">
                        {seg.start}s – {seg.end}s
                      </p>
                      <p className="text-sm mt-1">{seg.summary}</p>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {activeTab === "past" && (
            <div className="flex h-full gap-6">
              {/* Past Guides List */}
              <div className="w-1/2 border border-slate-200 rounded-lg overflow-hidden flex flex-col">
                <div className="px-4 py-3 border-b border-slate-200 bg-slate-50 flex items-center justify-between">
                  <div>
                    <h2 className="text-lg font-semibold">Past Study Guides</h2>
                    <p className="text-xs text-slate-500">
                      Total: {pastGuidesTotal}
                    </p>
                  </div>
                  <button
                    onClick={fetchPastGuides}
                    disabled={pastGuidesLoading}
                    className="text-xs px-3 py-1 rounded bg-slate-200 hover:bg-slate-300 disabled:bg-slate-100"
                  >
                    {pastGuidesLoading ? "Refreshing..." : "Refresh"}
                  </button>
                </div>

                <div className="flex-1 overflow-auto">
                  {pastGuidesLoading && pastGuides.length === 0 && (
                    <div className="p-4 text-sm text-slate-500">
                      Loading past guides...
                    </div>
                  )}

                  {!pastGuidesLoading && pastGuides.length === 0 && (
                    <div className="p-4 text-sm text-slate-500">
                      No study guides found yet. Generate one from the Content
                      Priority Tagger tab.
                    </div>
                  )}

                  <table className="min-w-full text-sm">
                    <thead className="bg-slate-100 border-b border-slate-200">
                      <tr>
                        <th className="text-left px-3 py-2 font-medium text-xs text-slate-600">
                          Title
                        </th>
                        <th className="text-left px-3 py-2 font-medium text-xs text-slate-600">
                          Status
                        </th>
                        <th className="text-left px-3 py-2 font-medium text-xs text-slate-600">
                          Duration
                        </th>
                        <th className="text-left px-3 py-2 font-medium text-xs text-slate-600">
                          Actions
                        </th>
                      </tr>
                    </thead>
                    <tbody>
                      {pastGuides.map((g) => {
                        const created = new Date(g.created_at);
                        const isSelected =
                          selectedPastGuide && selectedPastGuide.id === g.id;

                        return (
                          <tr
                            key={g.id}
                            className={`cursor-pointer hover:bg-slate-50 ${isSelected ? "bg-slate-100" : ""
                              }`}
                            onClick={() => setSelectedPastGuide(g)}
                          >
                            <td className="px-3 py-2 border-b border-slate-100">
                              <div className="font-medium truncate max-w-[180px]">
                                {g.title}
                              </div>
                              <div className="text-xs text-slate-500 truncate max-w-[180px]">
                                {g.video_title}
                              </div>
                            </td>
                            <td className="px-3 py-2 border-b border-slate-100">
                              <span
                                className={`inline-flex px-2 py-0.5 rounded-full text-xs font-medium ${g.status === "COMPLETED"
                                  ? "bg-green-100 text-green-700"
                                  : g.status === "FAILED"
                                    ? "bg-red-100 text-red-700"
                                    : "bg-amber-100 text-amber-700"
                                  }`}
                              >
                                {g.status}
                              </span>
                            </td>
                            <td className="px-3 py-2 border-b border-slate-100 text-xs text-slate-600">
                              {Math.round(g.video_duration)}s
                            </td>
                            <td className="px-3 py-2 border-b border-slate-100 space-x-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleExportPDF(g);
                                }}
                                className="text-xs text-green-600 hover:underline"
                              >
                                Export
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  openPreview(g.id);
                                }}
                                className="text-xs text-blue-600 hover:underline"
                              >
                                Preview
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Selected Guide Detail */}
              <div className="flex-1 border border-slate-200 rounded-lg p-4 bg-white overflow-auto">
                {!selectedPastGuide && (
                  <p className="text-sm text-slate-500">
                    Select a guide from the left to view its details.
                  </p>
                )}

                {selectedPastGuide && (
                  <>
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h2 className="text-xl font-bold mb-1">
                          {selectedPastGuide.title}
                        </h2>
                        <p className="text-sm text-slate-500">
                          {selectedPastGuide.video_title}
                        </p>
                      </div>
                      <span
                        className={`inline-flex px-3 py-1 rounded-full text-xs font-semibold mt-1 ${selectedPastGuide.status === "COMPLETED"
                          ? "bg-green-100 text-green-700"
                          : selectedPastGuide.status === "FAILED"
                            ? "bg-red-100 text-red-700"
                            : "bg-amber-100 text-amber-700"
                          }`}
                      >
                        {selectedPastGuide.status}
                      </span>
                    </div>

                    <div className="flex items-center gap-4 text-xs text-slate-500 mb-4">
                      <span>
                        Duration:{" "}
                        {Math.round(selectedPastGuide.video_duration)} seconds
                      </span>
                      <span>
                        Created:{" "}
                        {new Date(
                          selectedPastGuide.created_at
                        ).toLocaleString()}
                      </span>
                      <a
                        href={selectedPastGuide.youtube_url}
                        target="_blank"
                        rel="noreferrer"
                        className="text-blue-600 underline"
                      >
                        Open video
                      </a>
                    </div>

                    {/* YouTube Video Embed */}
                    {selectedPastGuide.video_id && (
                      <div className="mb-6">
                        <iframe
                          width="100%"
                          height="315"
                          src={getYouTubeEmbedUrl(selectedPastGuide.video_id)}
                          title={selectedPastGuide.video_title}
                          frameBorder="0"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                          allowFullScreen
                          className="rounded-lg"
                        ></iframe>
                      </div>
                    )}

                    <h3 className="text-sm font-semibold mb-2">Summary</h3>
                    <div className="border border-slate-200 rounded-lg p-3 bg-slate-50 prose prose-sm max-w-none mb-4">
                      <ReactMarkdown>
                        {selectedPastGuide.content}
                      </ReactMarkdown>
                    </div>

                    <h3 className="text-sm font-semibold mb-2">Key Topics</h3>
                    {selectedPastGuide.key_topics.length === 0 && (
                      <p className="text-xs text-slate-500 mb-3">
                        No key topics available.
                      </p>
                    )}
                    {selectedPastGuide.key_topics.length > 0 && (
                      <ul className="list-disc ml-6 text-sm mb-4 space-y-1">
                        {selectedPastGuide.key_topics.map((t, i) => (
                          <li key={i}>{t}</li>
                        ))}
                      </ul>
                    )}

                    <h3 className="text-sm font-semibold mb-2">Segments</h3>
                    {selectedPastGuide.segments.length === 0 && (
                      <p className="text-xs text-slate-500">
                        No segments for this guide.
                      </p>
                    )}
                    {selectedPastGuide.segments.map((seg, i) => (
                      <div
                        key={seg.id ?? i}
                        className="border border-slate-200 rounded-lg p-3 mb-2 bg-slate-50"
                      >
                        <p className="font-semibold text-sm">{seg.title}</p>
                        <p className="text-xs text-slate-600">
                          {seg.start}s – {seg.end}s
                        </p>
                        <p className="text-sm mt-1">{seg.summary}</p>
                      </div>
                    ))}
                  </>
                )}
              </div>
            </div>
          )}

          {activeTab === "feedback" && (
            <>
              <h1 className="text-[28px] font-bold mb-4">Student Feedback</h1>
              <p className="text-sm text-slate-600 mb-6">
                Collect feedback from learners to improve future study guides.
              </p>

              {/* Submit Feedback Form */}
              <div className="border border-slate-200 rounded-lg p-6 bg-white mb-6">
                <h2 className="text-lg font-semibold mb-4">Submit Your Feedback</h2>

                <p className="text-sm font-medium mb-3">Rate this study guide</p>
                <div className="flex gap-3 mb-6">
                  {[1, 2, 3, 4, 5].map((rating) => (
                    <button
                      key={rating}
                      onClick={() => setSelectedRating(rating)}
                      className={`px-4 py-2 border rounded-lg text-sm font-medium transition ${selectedRating === rating
                        ? "bg-blue-600 text-white border-blue-600"
                        : "border-slate-300 hover:bg-slate-100"
                        }`}
                    >
                      {rating} ★
                    </button>
                  ))}
                </div>

                <p className="text-sm font-medium mb-2">
                  What could be improved?
                </p>
                <textarea
                  value={feedbackComment}
                  onChange={(e) => setFeedbackComment(e.target.value)}
                  className="border border-slate-300 rounded-lg p-3 w-full min-h-32 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
                  placeholder="Share suggestions on clarity, coverage, pacing, or additional examples needed."
                ></textarea>

                <button
                  onClick={submitFeedback}
                  disabled={submittingFeedback}
                  className="px-4 py-2 bg-black text-white rounded-lg text-sm font-medium hover:bg-slate-800 disabled:bg-slate-400"
                >
                  {submittingFeedback ? "Submitting..." : "Submit Feedback"}
                </button>
              </div>

              {/* Display Existing Feedback */}
              <div className="border border-slate-200 rounded-lg p-6 bg-white">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-lg font-semibold">Recent Feedback</h2>
                  <button
                    onClick={fetchFeedback}
                    disabled={feedbackLoading}
                    className="text-xs px-3 py-1 rounded bg-slate-200 hover:bg-slate-300 disabled:bg-slate-100"
                  >
                    {feedbackLoading ? "Loading..." : "Refresh"}
                  </button>
                </div>

                {feedbackLoading && feedbacks.length === 0 && (
                  <p className="text-sm text-slate-500">Loading feedback...</p>
                )}

                {!feedbackLoading && feedbacks.length === 0 && (
                  <p className="text-sm text-slate-500">
                    No feedback submitted yet. Be the first to share your thoughts!
                  </p>
                )}

                <div className="space-y-4">
                  {feedbacks.map((fb) => (
                    <div
                      key={fb.id}
                      className="border border-slate-200 rounded-lg p-4 bg-slate-50"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-lg">
                            {fb.rating} ★
                          </span>
                          <span className="text-xs text-slate-500">
                            {new Date(fb.created_at).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <p className="text-sm text-slate-700">{fb.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
        </div>
      </div>

      {/* PREVIEW MODAL */}
      <Transition appear show={isPreviewOpen} as={Fragment}>
        <Dialog as="div" className="relative z-50" onClose={closePreview}>
          <Transition.Child
            as={Fragment}
            enter="ease-out duration-300"
            enterFrom="opacity-0"
            enterTo="opacity-100"
            leave="ease-in duration-200"
            leaveFrom="opacity-100"
            leaveTo="opacity-0"
          >
            <div className="fixed inset-0 bg-black bg-opacity-50" />
          </Transition.Child>

          <div className="fixed inset-0 overflow-y-auto">
            <div className="flex min-h-full items-center justify-center p-4">
              <Transition.Child
                as={Fragment}
                enter="ease-out duration-300"
                enterFrom="opacity-0 scale-95"
                enterTo="opacity-100 scale-100"
                leave="ease-in duration-200"
                leaveFrom="opacity-100 scale-100"
                leaveTo="opacity-0 scale-95"
              >
                <Dialog.Panel className="w-full max-w-4xl transform overflow-hidden rounded-lg bg-white shadow-xl transition-all">
                  {/* Modal Header */}
                  <div className="flex items-center justify-between px-6 py-4 border-b border-slate-200">
                    <Dialog.Title className="text-xl font-bold">
                      Study Guide Preview
                    </Dialog.Title>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() =>
                          previewGuide && handleExportPDF(previewGuide)
                        }
                        disabled={isExporting}
                        className="flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300 text-white rounded-lg text-sm font-medium"
                      >
                        <Download className="w-4 h-4" />
                        {isExporting ? "Exporting..." : "Export PDF"}
                      </button>
                      <button
                        onClick={closePreview}
                        className="p-2 hover:bg-slate-100 rounded-lg"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  </div>

                  {/* Modal Content */}
                  <div className="px-6 py-4 max-h-[70vh] overflow-y-auto">
                    {previewLoading && (
                      <div className="text-center py-8 text-slate-500">
                        Loading preview...
                      </div>
                    )}

                    {!previewLoading && previewGuide && (
                      <div className="space-y-6">
                        {/* Header */}
                        <div className="border-b pb-4">
                          <h1 className="text-2xl font-bold mb-2">
                            {previewGuide.title}
                          </h1>
                          <p className="text-sm text-slate-600">
                            {previewGuide.video_title}
                          </p>
                          <div className="flex items-center gap-4 text-xs text-slate-500 mt-2">
                            <span>
                              Duration:{" "}
                              {Math.round(previewGuide.video_duration)} seconds
                            </span>
                            <span>
                              Created:{" "}
                              {new Date(
                                previewGuide.created_at
                              ).toLocaleDateString()}
                            </span>
                          </div>
                        </div>

                        {/* Content */}
                        <div>
                          <h3 className="text-lg font-semibold mb-2">
                            Summary
                          </h3>
                          <div className="prose prose-sm max-w-none">
                            <ReactMarkdown>{previewGuide.content}</ReactMarkdown>
                          </div>
                        </div>

                        {/* Key Topics */}
                        {previewGuide.key_topics.length > 0 && (
                          <div>
                            <h3 className="text-lg font-semibold mb-2">
                              Key Topics
                            </h3>
                            <ul className="list-disc ml-6 text-sm space-y-1">
                              {previewGuide.key_topics.map((t, i) => (
                                <li key={i}>{t}</li>
                              ))}
                            </ul>
                          </div>
                        )}

                        {/* Segments */}
                        {previewGuide.segments.length > 0 && (
                          <div>
                            <h3 className="text-lg font-semibold mb-2">
                              Segments
                            </h3>
                            {previewGuide.segments.map((seg, i) => (
                              <div
                                key={seg.id ?? i}
                                className="border border-slate-200 rounded-lg p-3 mb-2 bg-slate-50"
                              >
                                <p className="font-semibold text-sm">
                                  {seg.title}
                                </p>
                                <p className="text-xs text-slate-600">
                                  {seg.start}s – {seg.end}s
                                </p>
                                <p className="text-sm mt-1">{seg.summary}</p>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                </Dialog.Panel>
              </Transition.Child>
            </div>
          </div>
        </Dialog>
      </Transition>
    </AppLayout>
  );
}
