"use client";

import { useEffect, useState, useRef } from "react";
import AppLayout from "@/components/AppLayout";
import { Search, HelpCircle, MessageSquare, Plus, ChevronDown, FileText, BookOpen, Upload, X } from "lucide-react";
import ReactMarkdown from "react-markdown";

// ================ TYPE DEFINITIONS ================

interface Course {
  id: number;
  code: string;
  name: string;
  description: string;
  created_at: string;
}

interface Document {
  id: number;
  course_id: number;
  title: string;
  content_preview: string;
  created_at: string;
  chunk_count: number;
}

interface Source {
  documents: Array<{
    chunk_index: number;
    document_id: number;
    course_id: number;
  }>;
}

interface ChatMessage {
  id: number;
  conversation_id: number;
  sender_type: "STUDENT" | "AI";
  content: string;
  confidence_score: number | null;
  sources: Source | null;
  timestamp: string;
}

interface Conversation {
  id: number;
  student_id: number;
  course_id: number;
  status: "ACTIVE" | "INACTIVE";
  started_at: string;
  last_message_at: string | null;
  messages: ChatMessage[];
}

interface ConversationsResponse {
  conversations: Conversation[];
  total: number;
}

interface ChatResponse {
  message: ChatMessage;
}

// ================ MAIN COMPONENT ================

export default function KnowledgeAssistant() {
  const [courses, setCourses] = useState<Course[]>([]);
  const [documents, setDocuments] = useState<Document[]>([]);
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [filteredConversations, setFilteredConversations] = useState<Conversation[]>([]);
  const [selectedConversation, setSelectedConversation] =
    useState<Conversation | null>(null);
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [question, setQuestion] = useState("");
  const [selectedMessage, setSelectedMessage] = useState<ChatMessage | null>(null);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [courseId, setCourseId] = useState<number | null>(null);
  const [coursesLoading, setCoursesLoading] = useState(true);
  const [documentsLoading, setDocumentsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'conversations' | 'documents'>('conversations');

  // Upload states
  const [uploadCourseId, setUploadCourseId] = useState<number | null>(null);
  const [uploadTitle, setUploadTitle] = useState("");
  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const API_BASE = "http://localhost:8000";
  const token =
    typeof window !== "undefined"
      ? localStorage.getItem("access_token")
      : null;

  // ---------------------------
  // Fetch courses
  // ---------------------------
  const fetchCourses = async () => {
    try {
      const res = await fetch(`${API_BASE}/courses`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data: Course[] = await res.json();
      setCourses(data);
    } catch (err) {
      console.error("Fetch courses error:", err);
    } finally {
      setCoursesLoading(false);
    }
  };

  // ---------------------------
  // Fetch all documents (no course_id)
  // ---------------------------
  const fetchDocuments = async () => {
    try {
      const res = await fetch(`${API_BASE}/knowledge/documents`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const data: Document[] = await res.json();
      setDocuments(data);
    } catch (err) {
      console.error("Fetch documents error:", err);
    } finally {
      setDocumentsLoading(false);
    }
  };

  // ---------------------------
  // Fetch all conversations (course_id empty by default)
  // ---------------------------
  const fetchConversations = async (courseIdParam?: number | null) => {
    try {
      const url = courseIdParam
        ? `${API_BASE}/knowledge/conversations?course_id=${courseIdParam}`
        : `${API_BASE}/knowledge/conversations`;

      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const data: ConversationsResponse = await res.json();

      const conversationsWithMessages = data.conversations.filter(
        (conv) => conv.messages.length > 0
      );

      setConversations(conversationsWithMessages);
      setFilteredConversations(conversationsWithMessages);

      if (conversationsWithMessages.length > 0 && !selectedConversation) {
        const mostRecent = conversationsWithMessages.reduce((prev, current) =>
          new Date(current.started_at) > new Date(prev.started_at)
            ? current
            : prev
        );
        selectConversation(mostRecent);
      }
    } catch (err) {
      console.error("Fetch conversations error:", err);
    }
  };

  // ---------------------------
  // Get course by ID
  // ---------------------------
  const getCourseById = (id: number): Course | undefined => {
    return courses.find(course => course.id === id);
  };

  // ---------------------------
  // Get document by ID
  // ---------------------------
  const getDocumentById = (id: number): Document | undefined => {
    return documents.find(doc => doc.id === id);
  };

  // ---------------------------
  // Filter conversations by course
  // ---------------------------
  const filterByCourse = (courseIdParam: number | null) => {
    setCourseId(courseIdParam);
    if (courseIdParam === null) {
      setFilteredConversations(conversations);
    } else {
      const filtered = conversations.filter((conv) => conv.course_id === courseIdParam);
      setFilteredConversations(filtered);
    }

    if (filteredConversations.length === 0 ||
      (courseIdParam !== null && !filteredConversations.some(conv => conv.course_id === courseIdParam))) {
      setSelectedConversation(null);
      setConversationId(null);
      setMessages([]);
      setSelectedMessage(null);
    }
  };

  // ---------------------------
  // Create new conversation (POST /knowledge/conversations)
  // ---------------------------
  const createConversation = async (courseIdParam?: number | null) => {
    try {
      const body = courseIdParam ? { course_id: courseIdParam } : {};

      const res = await fetch(`${API_BASE}/knowledge/conversations`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(body),
      });

      if (res.ok) {
        const data: Conversation = await res.json();
        fetchConversations(courseId);
        return data;
      }
    } catch (err) {
      console.error("Create conversation error:", err);
    }
  };

  // ---------------------------
  // Upload document (POST /knowledge/documents)
  // ---------------------------
  const uploadDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadCourseId || !uploadTitle || !uploadFile) return;

    setUploading(true);

    try {
      const formData = new FormData();
      formData.append("course_id", uploadCourseId.toString());
      formData.append("title", uploadTitle);
      formData.append("file", uploadFile);

      const res = await fetch(`${API_BASE}/knowledge/documents`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
        },
        body: formData,
      });

      if (res.ok) {
        // Reset form
        setUploadCourseId(null);
        setUploadTitle("");
        setUploadFile(null);
        if (fileInputRef.current) fileInputRef.current.value = "";

        // Refresh documents and conversations
        fetchDocuments();
        fetchConversations(courseId);

        alert("Document uploaded successfully!");
      } else {
        alert("Upload failed. Please try again.");
      }
    } catch (err) {
      console.error("Upload document error:", err);
      alert("Upload failed. Please check console for details.");
    } finally {
      setUploading(false);
    }
  };

  // ---------------------------
  // Select a conversation
  // ---------------------------
  const selectConversation = (conversation: Conversation) => {
    setSelectedConversation(conversation);
    setConversationId(conversation.id);
    setMessages(conversation.messages);

    const lastAIMessage = [...conversation.messages]
      .reverse()
      .find((m) => m.sender_type === "AI");
    if (lastAIMessage) {
      setSelectedMessage(lastAIMessage);
    }
  };

  // ---------------------------
  // Load conversation details
  // ---------------------------
  const loadConversation = async (id: number) => {
    try {
      const res = await fetch(`${API_BASE}/knowledge/conversations/${id}`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const data: Conversation = await res.json();

      if (data.messages.length > 0) {
        setMessages(data.messages);
        setSelectedConversation(data);
      }
    } catch (err) {
      console.error("Load conversation error:", err);
    }
  };

  // ---------------------------
  // Chat query (POST /knowledge/chat)
  // ---------------------------
  const askQuery = async () => {
    if (!question.trim() || !conversationId) return;

    setLoading(true);

    try {
      const body = {
        query: question,
        conversation_id: conversationId,
        ...(courseId && { course_id: courseId }),
      };

      const res = await fetch(`${API_BASE}/knowledge/chat`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(body),
      });

      const data: ChatResponse = await res.json();

      await loadConversation(conversationId);
      setQuestion("");

      if (data.message) {
        setSelectedMessage(data.message);
      }

      fetchConversations(courseId);
    } catch (err) {
      console.error("Chat error:", err);
      alert("Error contacting AI assistant.");
    } finally {
      setLoading(false);
    }
  };

  // Handle Enter key press
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      askQuery();
    }
  };

  // Initialize
  useEffect(() => {
    fetchCourses();
    fetchDocuments();
  }, []);

  useEffect(() => {
    if (!coursesLoading && !documentsLoading) {
      fetchConversations();
    }
  }, [coursesLoading, documentsLoading]);

  // Calculate stats
  const totalMessages = messages.length;
  const aiReplies = messages.filter((m) => m.sender_type === "AI").length;
  const studentQuestions = messages.filter(
    (m) => m.sender_type === "STUDENT"
  ).length;

  return (
    <AppLayout>
      <div className="flex h-[calc(100vh-57px)]">
        {/* LEFT SIDEBAR */}
        <div className="w-[400px] border-r bg-white p-4 overflow-auto">
          {/* Tabs */}
          <div className="flex border-b border-[#E8EDF2] mb-6">
            <button
              onClick={() => setActiveTab('conversations')}
              className={`flex-1 py-3 px-4 text-sm font-medium border-b-2 transition-colors ${activeTab === 'conversations'
                ? 'border-blue-600 text-[#0D141C]'
                : 'border-transparent text-[#4D7399] hover:text-[#0D141C]'
                }`}
            >
              Conversations ({filteredConversations.length})
            </button>
            <button
              onClick={() => setActiveTab('documents')}
              className={`flex-1 py-3 px-4 text-sm font-medium border-b-2 transition-colors ${activeTab === 'documents'
                ? 'border-blue-600 text-[#0D141C]'
                : 'border-transparent text-[#4D7399] hover:text-[#0D141C]'
                }`}
            >
              Documents ({documents.length})
            </button>
          </div>

          {/* CONVERSATIONS TAB */}
          {activeTab === 'conversations' && (
            <>
              <div className="mb-4">
                <label className="block text-sm font-medium text-[#0D141C] mb-2">
                  Filter by Course
                </label>
                <div className="relative">
                  <select
                    value={courseId || ""}
                    onChange={(e) => filterByCourse(e.target.value ? parseInt(e.target.value) : null)}
                    className="w-full appearance-none bg-[#F7FAFC] border border-[#CFDBE8] rounded-lg px-4 py-2 pr-10 text-[#0D141C] focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="">All Courses</option>
                    {courses.map((course) => (
                      <option key={course.id} value={course.id}>
                        {course.code} - {course.name}
                      </option>
                    ))}
                  </select>
                  <ChevronDown className="w-4 h-4 absolute right-3 top-1/2 transform -translate-y-1/2 text-[#4D7399] pointer-events-none" />
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-[#0D141C] mb-2">
                  Start New Conversation
                </label>
                <div className="relative">
                  <select
                    onChange={(e) => createConversation(e.target.value ? parseInt(e.target.value) : null)}
                    defaultValue=""
                    className="w-full appearance-none bg-blue-600 text-white border border-blue-600 rounded-lg px-4 py-2 pr-10 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent cursor-pointer"
                  >
                    <option value="" disabled>Select course...</option>
                    {courses.map((course) => (
                      <option key={`new-${course.id}`} value={course.id}>
                        {course.code} - {course.name}
                      </option>
                    ))}
                  </select>
                  <Plus className="w-4 h-4 absolute right-3 top-1/2 transform -translate-y-1/2 text-white pointer-events-none" />
                </div>
              </div>

              <div className="text-xs text-[#4D7399] mb-4 grid grid-cols-2 gap-2">
                <div>Showing {filteredConversations.length}</div>
                <div>Total {conversations.length}</div>
              </div>

              <div className="flex flex-col gap-2">
                {filteredConversations.map((conv) => {
                  const course = getCourseById(conv.course_id);
                  return (
                    <div
                      key={conv.id}
                      onClick={() => selectConversation(conv)}
                      className={`p-3 rounded-lg cursor-pointer border transition-colors group hover:shadow-sm ${conversationId === conv.id
                        ? "bg-blue-50 border-blue-300 shadow-sm"
                        : "bg-[#F7FAFC] border-transparent hover:bg-[#eef3f6]"
                        }`}
                      title={course?.name}
                    >
                      <div className="flex items-start gap-2">
                        <MessageSquare className="w-5 h-5 text-[#4D7399] flex-shrink-0 mt-0.5 group-hover:text-blue-600 transition-colors" />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="text-sm font-medium text-[#0D141C] truncate flex-1">
                              Conversation #{conv.id}
                            </p>
                            <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-xs rounded-full">
                              {course?.code || conv.course_id}
                            </span>
                          </div>
                          <p className="text-xs text-[#4D7399] truncate">
                            {course?.name || `Course #${conv.course_id}`}
                          </p>
                          <p className="text-xs text-[#4D7399]">
                            {conv.messages.length} messages • {formatDateTime(conv.started_at)}
                          </p>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {filteredConversations.length === 0 && (
                  <div className="text-center py-8 text-[#4D7399]">
                    <MessageSquare className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">
                      {courseId === null
                        ? "No conversations with messages yet."
                        : `No conversations with messages for this course`}
                    </p>
                    <p className="text-xs mt-1">Start a new conversation above!</p>
                  </div>
                )}
              </div>
            </>
          )}

          {/* DOCUMENTS TAB */}
          {activeTab === 'documents' && (
            <>
              {/* Upload Form */}
              <div className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h3 className="text-sm font-bold text-[#0D141C] mb-3 flex items-center gap-2">
                  <Upload className="w-4 h-4" />
                  Upload New Document
                </h3>

                <form onSubmit={uploadDocument} className="space-y-3">
                  <div>
                    <label className="block text-xs font-medium text-[#0D141C] mb-1">
                      Course
                    </label>
                    <select
                      value={uploadCourseId || ""}
                      onChange={(e) => setUploadCourseId(e.target.value ? parseInt(e.target.value) : null)}
                      required
                      className="w-full bg-white border border-[#CFDBE8] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      disabled={uploading}
                    >
                      <option value="">Select course...</option>
                      {courses.map((course) => (
                        <option key={course.id} value={course.id}>
                          {course.code} - {course.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#0D141C] mb-1">
                      Document Title
                    </label>
                    <input
                      type="text"
                      value={uploadTitle}
                      onChange={(e) => setUploadTitle(e.target.value)}
                      placeholder="Enter document title"
                      required
                      className="w-full bg-white border border-[#CFDBE8] rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                      disabled={uploading}
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#0D141C] mb-1">
                      File
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        ref={fileInputRef}
                        type="file"
                        onChange={(e) => setUploadFile(e.target.files?.[0] || null)}
                        accept=".pdf,.txt,.doc,.docx"
                        required
                        className="flex-1 text-sm file:mr-2 file:py-1 file:px-3 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
                        disabled={uploading}
                      />
                      {uploadFile && (
                        <button
                          type="button"
                          onClick={() => {
                            setUploadFile(null);
                            if (fileInputRef.current) fileInputRef.current.value = "";
                          }}
                          className="p-1 text-gray-500 hover:text-gray-700"
                          disabled={uploading}
                        >
                          <X className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                    {uploadFile && (
                      <p className="text-xs text-[#4D7399] mt-1">{uploadFile.name}</p>
                    )}
                  </div>

                  <button
                    type="submit"
                    disabled={!uploadCourseId || !uploadTitle || !uploadFile || uploading}
                    className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg text-sm font-medium hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors flex items-center justify-center gap-2"
                  >
                    {uploading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                        Uploading...
                      </>
                    ) : (
                      <>
                        <Upload className="w-4 h-4" />
                        Upload Document
                      </>
                    )}
                  </button>
                </form>
              </div>

              {/* Documents List */}
              <div className="space-y-3">
                {documentsLoading ? (
                  <div className="text-center py-8 text-[#4D7399]">
                    <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>Loading documents...</p>
                  </div>
                ) : documents.length === 0 ? (
                  <div className="text-center py-8 text-[#4D7399]">
                    <FileText className="w-12 h-12 mx-auto mb-2 opacity-50" />
                    <p>No documents available. Upload your first document above!</p>
                  </div>
                ) : (
                  documents.map((doc) => {
                    const course = getCourseById(doc.course_id);
                    return (
                      <div
                        key={doc.id}
                        className="p-4 bg-[#F7FAFC] rounded-lg border border-[#E8EDF2] hover:shadow-sm hover:border-blue-300 transition-all group"
                        title={doc.content_preview}
                      >
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                            <FileText className="w-5 h-5 text-blue-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <p className="text-sm font-medium text-[#0D141C] truncate flex-1">
                                Document #{doc.id}
                              </p>
                              <span className="px-2 py-0.5 bg-green-100 text-green-800 text-xs rounded-full">
                                {doc.chunk_count} chunks
                              </span>
                            </div>
                            <p className="text-xs text-[#4D7399] truncate mb-1">
                              {course?.code || doc.course_id} - {course?.name || 'Unknown Course'}
                            </p>
                            <p className="text-xs text-[#4D7399] line-clamp-2">
                              {doc.content_preview}
                            </p>
                            <p className="text-xs text-[#9CA3AF] mt-1">
                              {formatDateTime(doc.created_at)}
                            </p>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </>
          )}
        </div>

        {/* MAIN AREA & RIGHT SIDEBAR - SAME AS BEFORE */}
        <div className="flex flex-1 min-w-0">
          {/* MAIN AREA */}
          <div className="flex-1 flex flex-col max-w-[920px] mx-auto p-4 overflow-auto">
            <h1 className="text-[32px] font-bold mb-6">AI Knowledge Assistant</h1>

            {!conversationId && (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 mb-6 text-center">
                <MessageSquare className="w-16 h-16 mx-auto mb-4 text-blue-400 opacity-70" />
                <p className="text-lg text-[#0D141C] mb-2">
                  Select a conversation or start a new one
                </p>
                <p className="text-[#4D7399]">
                  Conversations with no messages are hidden until you ask your first question.
                </p>
              </div>
            )}

            {/* INPUT BAR */}
            {conversationId && (
              <div className="flex gap-2 mb-6">
                <div className="flex items-center bg-[#E8EDF2] rounded-lg px-4 flex-1">
                  <Search className="w-6 h-6 text-[#4D7399]" />
                  <input
                    value={question}
                    onChange={(e) => setQuestion(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Ask a question"
                    disabled={!conversationId || loading}
                    className="flex-1 py-3 px-2 bg-transparent outline-none text-[#0D141C] placeholder:text-[#4D7399] disabled:opacity-50"
                  />
                </div>

                <button
                  onClick={askQuery}
                  disabled={loading || !conversationId || !question.trim()}
                  className="bg-blue-600 text-white px-6 rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
                >
                  {loading ? "Thinking..." : "Ask"}
                </button>
              </div>
            )}

            {/* MESSAGES */}
            {conversationId && (
              <>
                <h2 className="text-[22px] font-bold mb-4">
                  Conversation #{conversationId}
                  {selectedConversation && (
                    <>
                      <span className="text-sm font-normal text-[#4D7399] ml-2">
                        (Course #{selectedConversation.course_id})
                      </span>
                      {(() => {
                        const course = getCourseById(selectedConversation.course_id);
                        return course ? (
                          <span className="text-sm font-normal text-[#4D7399] ml-1">
                            - {course.code}
                          </span>
                        ) : null;
                      })()}
                    </>
                  )}
                </h2>

                <div className="flex flex-col gap-3">
                  {messages.length === 0 ? (
                    <div className="text-center py-8 text-[#4D7399]">
                      <HelpCircle className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>No messages yet. Ask your first question above!</p>
                    </div>
                  ) : (
                    messages.map((msg) => (
                      <div
                        key={msg.id}
                        className={`cursor-pointer p-4 rounded-lg border transition-all ${selectedMessage?.id === msg.id
                          ? "bg-blue-50 border-blue-300 shadow-sm"
                          : "bg-[#F7FAFC] border-transparent hover:bg-[#eef3f6]"
                          }`}
                        onClick={() => setSelectedMessage(msg)}
                      >
                        <div className="flex items-start gap-3">
                          <div
                            className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${msg.sender_type === "STUDENT"
                              ? "bg-[#4D7399]"
                              : "bg-[#E8EDF2]"
                              }`}
                          >
                            {msg.sender_type === "STUDENT" ? (
                              <span className="text-white font-bold text-sm">You</span>
                            ) : (
                              <HelpCircle className="w-6 h-6 text-[#0D141C]" />
                            )}
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center justify-between mb-1">
                              <p className="font-semibold text-[#0D141C]">
                                {msg.sender_type === "STUDENT"
                                  ? "You"
                                  : "AI Assistant"}
                              </p>
                              <span className="text-xs text-[#4D7399]">
                                {formatTime(msg.timestamp)}
                              </span>
                            </div>

                            <div className="text-[#4D7399] text-sm line-clamp-3">
                              {msg.content}
                            </div>

                            {msg.confidence_score !== null && (
                              <div className="mt-2">
                                <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded">
                                  Confidence: {(msg.confidence_score * 100).toFixed(0)}%
                                </span>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </>
            )}
          </div>

          {/* RIGHT SIDEBAR */}
          <div className="hidden xl:block w-[360px] border-l bg-white p-4 overflow-auto">
            <h2 className="text-[22px] font-bold mb-4">AI Response</h2>

            {selectedMessage ? (
              <>
                {selectedMessage.sources &&
                  selectedMessage.sources.documents &&
                  selectedMessage.sources.documents.length > 0 && (
                    <div className="mb-6">
                      <h3 className="text-[18px] font-bold mb-3 flex items-center gap-2">
                        <BookOpen className="w-5 h-5" />
                        Referenced Documents
                      </h3>
                      <div className="space-y-2">
                        {selectedMessage.sources.documents.map((refDoc, idx) => {
                          const document = getDocumentById(refDoc.document_id);
                          const course = getCourseById(refDoc.course_id);
                          return (
                            <div key={idx} className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                              <div className="flex items-start gap-2">
                                <FileText className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                                <div className="flex-1 min-w-0">
                                  <p className="font-medium text-[#0D141C] text-sm truncate">
                                    {document?.title || `Document #${refDoc.document_id}`}
                                  </p>
                                  <p className="text-xs text-[#4D7399]">
                                    Chunk {refDoc.chunk_index} • {course?.code || refDoc.course_id}
                                  </p>
                                </div>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}

                <div className="prose prose-sm max-w-none mb-6">
                  <ReactMarkdown
                    components={{
                      p: ({ children }) => (
                        <p className="text-base leading-6 text-[#0D141C] mb-3">{children}</p>
                      ),
                      h1: ({ children }) => (
                        <h1 className="text-xl font-bold text-[#0D141C] mb-2">{children}</h1>
                      ),
                      h2: ({ children }) => (
                        <h2 className="text-lg font-bold text-[#0D141C] mb-2">{children}</h2>
                      ),
                      h3: ({ children }) => (
                        <h3 className="text-base font-bold text-[#0D141C] mb-2">{children}</h3>
                      ),
                      ul: ({ children }) => (
                        <ul className="list-disc pl-5 mb-3 text-[#0D141C]">{children}</ul>
                      ),
                      ol: ({ children }) => (
                        <ol className="list-decimal pl-5 mb-3 text-[#0D141C]">{children}</ol>
                      ),
                      code: ({ children }) => (
                        <code className="bg-gray-100 px-1 py-0.5 rounded text-sm">{children}</code>
                      ),
                      table: ({ children }) => (
                        <table className="border-collapse border border-gray-300 w-full mb-3">{children}</table>
                      ),
                      th: ({ children }) => (
                        <th className="border border-gray-300 px-2 py-1 bg-gray-100">{children}</th>
                      ),
                      td: ({ children }) => (
                        <td className="border border-gray-300 px-2 py-1">{children}</td>
                      ),
                    }}
                  >
                    {selectedMessage.content}
                  </ReactMarkdown>
                </div>

                {selectedMessage.confidence_score !== null && (
                  <div className="mb-6">
                    <h3 className="text-[18px] font-bold mb-3">Confidence Score</h3>
                    <div className="p-3 bg-[#F7FAFC] rounded">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-[#0D141C]">Accuracy</span>
                        <span className="font-bold text-[#0D141C]">
                          {(selectedMessage.confidence_score * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="bg-blue-600 h-2 rounded-full transition-all"
                          style={{ width: `${selectedMessage.confidence_score * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <p className="text-base leading-6 text-[#4D7399]">
                Select a message to view details and formatted response.
              </p>
            )}

            <h3 className="text-[22px] font-bold mt-6 mb-3">Analytics Summary</h3>
            <div className="grid grid-cols-2 gap-4">
              <Metric title="Total Messages" value={totalMessages} />
              <Metric title="AI Replies" value={aiReplies} />
              <Metric title="Your Questions" value={studentQuestions} />
              <Metric title="Active Conversations" value={filteredConversations.length} />
              <Metric title="Documents" value={documents.length} />
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

// ================ HELPER COMPONENTS ================

function Metric({ title, value }: { title: string; value: number; }) {
  return (
    <div className="p-4 rounded-lg border border-[#CFDBE8]">
      <div className="text-sm font-medium text-[#4D7399]">{title}</div>
      <div className="text-2xl font-bold text-[#0D141C]">{value}</div>
    </div>
  );
}

// ================ UTILITY FUNCTIONS ================

function formatTime(timestamp: string): string {
  return new Date(timestamp).toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
  });
}

function formatDateTime(timestamp: string): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return "Just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;

  return date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });
}
