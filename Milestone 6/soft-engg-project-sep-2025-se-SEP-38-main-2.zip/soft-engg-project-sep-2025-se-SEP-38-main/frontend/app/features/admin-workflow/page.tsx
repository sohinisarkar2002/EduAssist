"use client";

import AppLayout from "@/components/AppLayout";
import { Clock, CheckCircle, XCircle, AlertCircle, Plus } from "lucide-react";
import { useEffect, useState } from "react";

// TypeScript Types
interface AgentReport {
  raw?: string;
  parsed?: {
    decision?: string;
    reasoning?: string;
    policy_check?: string;
  } | null;
  error?: string;
  [key: string]: any; // For additionalProp from API
}

interface WorkflowRequest {
  id: number;
  title: string;
  description: string;
  request_type: string;
  status: string;
  agent_decision: string | null;
  admin_decision: string | null;
  agent_reasoning: string | null;
  last_run_report: AgentReport | null;
  created_at: string;
  resolved_at: string | null;
}

export default function AdminWorkflow() {
  // Form fields
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [requestType, setRequestType] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Data states
  const [workflowList, setWorkflowList] = useState<WorkflowRequest[]>([]);
  const [selectedRequest, setSelectedRequest] = useState<WorkflowRequest | null>(null);

  const API_BASE = process.env.NEXT_PUBLIC_API_URL;
  const token =
    typeof window !== "undefined" ? localStorage.getItem("access_token") : null;

  // -------------------------------------------------
  // HELPER: Extract JSON from markdown code blocks
  // -------------------------------------------------
  const extractJsonFromMarkdown = (text: string): any | null => {
    if (!text) return null;

    try {
      return JSON.parse(text);
    } catch {
      const codeBlockRegex = /``````/;
      const match = text.match(codeBlockRegex);

      if (match && match[1]) {
        try {
          return JSON.parse(match[1].trim());
        } catch (e) {
          console.error("Failed to parse JSON from code block:", e);
          return null;
        }
      }

      return null;
    }
  };

  // -------------------------------------------------
  // HELPER: Parse agent reasoning
  // -------------------------------------------------
  const parseAgentReasoning = (reasoning: string | null): any => {
    if (!reasoning) return null;

    const extracted = extractJsonFromMarkdown(reasoning);
    if (extracted) return extracted;

    return { raw: reasoning };
  };

  // Status badge helper
  const getStatusBadge = (status: string) => {
    const statusConfig: Record<string, { color: string; icon: any; bg: string; }> = {
      PENDING: { color: "text-yellow-700", icon: Clock, bg: "bg-yellow-100" },
      IN_PROGRESS: { color: "text-blue-700", icon: AlertCircle, bg: "bg-blue-100" },
      AUTO_APPROVED: { color: "text-green-700", icon: CheckCircle, bg: "bg-green-100" },
      REJECTED: { color: "text-red-700", icon: XCircle, bg: "bg-red-100" },
      ERROR: { color: "text-gray-700", icon: XCircle, bg: "bg-gray-100" },
    };

    const config = statusConfig[status] || statusConfig.PENDING;
    const Icon = config.icon;

    return (
      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${config.bg} ${config.color}`}>
        <Icon className="w-3 h-3" />
        {status.replace(/_/g, " ")}
      </span>
    );
  };

  // -------------------------------------------------
  // FETCH WORKFLOW LIST
  // -------------------------------------------------
  const loadWorkflowList = async () => {
    try {
      const res = await fetch(`${API_BASE}/workflow/workflow-requests/`, {
        headers: { Authorization: `Bearer ${token}` },
      });

      const data: WorkflowRequest[] = await res.json();
      setWorkflowList(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    loadWorkflowList();
  }, []);

  // -------------------------------------------------
  // CREATE WORKFLOW REQUEST
  // -------------------------------------------------
  const submitWorkflowRequest = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title || !description || !requestType) {
      alert("Please fill in all fields");
      return;
    }

    setIsSubmitting(true);

    try {
      const res = await fetch(`${API_BASE}/workflow/workflow-requests/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title,
          description,
          request_type: requestType,
        }),
      });

      const data: WorkflowRequest = await res.json();

      if (data.id) {
        // Clear form
        setTitle("");
        setDescription("");
        setRequestType("");

        // Reload list and select new request
        await loadWorkflowList();
        setSelectedRequest(data);
      } else {
        alert("Failed to submit request.");
      }
    } catch (err) {
      console.error(err);
      alert("Error submitting request");
    } finally {
      setIsSubmitting(false);
    }
  };

  // -------------------------------------------------
  // POLLING FOR SELECTED REQUEST
  // -------------------------------------------------
  useEffect(() => {
    if (!selectedRequest?.id) return;

    const poll = setInterval(async () => {
      try {
        const res = await fetch(
          `${API_BASE}/workflow/workflow-requests/${selectedRequest.id}`,
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        const data: WorkflowRequest = await res.json();
        setSelectedRequest(data);

        // Update in list too
        setWorkflowList(prev =>
          prev.map(req => req.id === data.id ? data : req)
        );
      } catch (err) {
        console.error(err);
      }
    }, 3000);

    return () => clearInterval(poll);
  }, [selectedRequest?.id]);

  return (
    <AppLayout>
      <div className="flex flex-1 gap-6 p-6">
        {/* Left Column: Past Requests */}
        <div className="flex-1 max-w-2xl">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-3xl font-bold">Workflow Requests</h1>
            <button
              onClick={() => setSelectedRequest(null)}
              className="text-sm text-blue-600 hover:text-blue-700"
            >
              Clear selection
            </button>
          </div>

          <div className="space-y-3">
            {workflowList.length === 0 ? (
              <div className="text-center py-12 bg-gray-50 rounded-lg border-2 border-dashed">
                <p className="text-gray-500">No requests yet. Submit your first request below!</p>
              </div>
            ) : (
              workflowList.map((req) => (
                <div
                  key={req.id}
                  className={`border rounded-lg p-4 cursor-pointer bg-white hover:shadow-md transition-all ${selectedRequest?.id === req.id ? "ring-2 ring-blue-500 shadow-md" : ""
                    }`}
                  onClick={() => setSelectedRequest(req)}
                >
                  <div className="flex justify-between items-start mb-2">
                    <p className="font-bold text-lg">{req.title}</p>
                    {getStatusBadge(req.status)}
                  </div>

                  <p className="text-sm text-gray-600 mb-3 line-clamp-2">{req.description}</p>

                  <div className="flex gap-4 text-xs text-gray-500">
                    <span>
                      Type: <strong className="text-gray-700">{req.request_type}</strong>
                    </span>
                    {req.agent_decision && (
                      <span>
                        Agent: <strong className="text-gray-700">{req.agent_decision}</strong>
                      </span>
                    )}
                    <span className="ml-auto">
                      {new Date(req.created_at).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right Column: Submit Form & Details */}
        <div className="w-[480px] space-y-6">
          {/* Submit New Request Form */}
          <div className="bg-white border rounded-lg p-6">
            <div className="flex items-center gap-2 mb-4">
              <Plus className="w-5 h-5 text-blue-600" />
              <h2 className="text-xl font-semibold">Submit New Request</h2>
            </div>

            <form onSubmit={submitWorkflowRequest} className="space-y-4">
              <div>
                <label className="block font-medium text-sm mb-1">Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., Extension Request for Assignment 2"
                  className="w-full border p-2 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <label className="block font-medium text-sm mb-1">Description</label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Provide details about your request..."
                  className="w-full border p-3 rounded-lg min-h-[120px] focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  disabled={isSubmitting}
                />
              </div>

              <div>
                <label className="block font-medium text-sm mb-1">Request Type</label>
                <input
                  type="text"
                  value={requestType}
                  onChange={(e) => setRequestType(e.target.value)}
                  placeholder="e.g., extension, Technical Issue"
                  className="w-full border p-2 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                  disabled={isSubmitting}
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full px-4 py-2 bg-[#1380ec] text-white rounded-lg font-semibold hover:bg-blue-600 transition-colors disabled:bg-gray-400 disabled:cursor-not-allowed"
              >
                {isSubmitting ? "Submitting..." : "Submit Request"}
              </button>
            </form>
          </div>

          {/* Selected Request Details */}
          {selectedRequest && (() => {
            const parsedReasoning = parseAgentReasoning(selectedRequest.agent_reasoning);
            const reportParsed = selectedRequest.last_run_report?.parsed;

            return (
              <div className="bg-white border rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Request Details</h2>

                <div className="space-y-4">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Title</p>
                    <p className="font-semibold">{selectedRequest.title}</p>
                  </div>

                  <div>
                    <p className="text-xs text-gray-500 mb-1">Description</p>
                    <p className="text-sm">{selectedRequest.description}</p>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Type</p>
                      <p className="font-medium text-sm">{selectedRequest.request_type}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Status</p>
                      <div className="mt-1">{getStatusBadge(selectedRequest.status)}</div>
                    </div>
                  </div>

                  {selectedRequest.agent_decision && (
                    <div>
                      <p className="text-xs text-gray-500 mb-1">Agent Decision</p>
                      <p className="font-medium text-sm">{selectedRequest.agent_decision}</p>
                    </div>
                  )}

                  {/* Parsed reasoning from agent_reasoning field */}
                  {parsedReasoning && parsedReasoning.reasoning && (
                    <div className="border-t pt-4">
                      <p className="text-sm font-semibold mb-3">Agent Analysis</p>

                      {parsedReasoning.decision && (
                        <div className="mb-3">
                          <p className="text-xs text-gray-500 mb-1">Decision</p>
                          <p className="text-xs font-medium bg-purple-50 p-2 rounded border border-purple-200">
                            {parsedReasoning.decision}
                          </p>
                        </div>
                      )}

                      <div className="mb-3">
                        <p className="text-xs text-gray-500 mb-1">Reasoning</p>
                        <p className="text-xs bg-blue-50 p-3 rounded border border-blue-200 whitespace-pre-wrap">
                          {parsedReasoning.reasoning}
                        </p>
                      </div>

                      {parsedReasoning.policy_check && (
                        <div>
                          <p className="text-xs text-gray-500 mb-1">Policy Check</p>
                          <p className="text-xs bg-green-50 p-3 rounded border border-green-200 whitespace-pre-wrap">
                            {parsedReasoning.policy_check}
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Fallback: raw agent_reasoning */}
                  {parsedReasoning?.raw && !parsedReasoning.reasoning && (
                    <div className="border-t pt-4">
                      <p className="text-xs text-gray-500 mb-1">Agent Reasoning</p>
                      <p className="text-xs bg-gray-50 p-3 rounded border whitespace-pre-wrap">
                        {parsedReasoning.raw}
                      </p>
                    </div>
                  )}

                  {/* last_run_report.parsed */}
                  {reportParsed && (
                    <div className="border-t pt-4">
                      <p className="text-sm font-semibold mb-3">Report Analysis</p>

                      {reportParsed.reasoning && (
                        <div className="mb-3">
                          <p className="text-xs text-gray-500 mb-1">Reasoning</p>
                          <p className="text-xs bg-blue-50 p-3 rounded border border-blue-200 whitespace-pre-wrap">
                            {reportParsed.reasoning}
                          </p>
                        </div>
                      )}

                      {reportParsed.policy_check && (
                        <div>
                          <p className="text-xs text-gray-500 mb-1">Policy Check</p>
                          <p className="text-xs bg-green-50 p-3 rounded border border-green-200 whitespace-pre-wrap">
                            {reportParsed.policy_check}
                          </p>
                        </div>
                      )}
                    </div>
                  )}

                  {selectedRequest.last_run_report?.error && (
                    <div className="border-t pt-4">
                      <p className="text-xs text-red-600 font-semibold mb-1">Error</p>
                      <p className="text-xs bg-red-50 p-3 rounded border border-red-200">
                        {selectedRequest.last_run_report.error}
                      </p>
                    </div>
                  )}

                  <div className="grid grid-cols-2 gap-4 pt-4 border-t text-xs text-gray-500">
                    <div>
                      <p className="mb-1">Created At</p>
                      <p className="font-medium text-gray-700">
                        {new Date(selectedRequest.created_at).toLocaleString()}
                      </p>
                    </div>
                    {selectedRequest.resolved_at && (
                      <div>
                        <p className="mb-1">Resolved At</p>
                        <p className="font-medium text-gray-700">
                          {new Date(selectedRequest.resolved_at).toLocaleString()}
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })()}
        </div>
      </div>
    </AppLayout>
  );
}
