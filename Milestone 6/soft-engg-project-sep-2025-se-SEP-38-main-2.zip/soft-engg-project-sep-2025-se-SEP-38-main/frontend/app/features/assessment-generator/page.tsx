"use client";

import AppLayout from "@/components/AppLayout";
import { useEffect, useState, useRef, useCallback } from "react";

// Types based on API response
interface Course {
  id: number;
  code: string;
  name: string;
  description: string;
  created_at: string;
}

interface Question {
  id: number;
  assessment_id?: number;
  question_type: string;
  question_text: string;
  options: string[];
  correct_answer?: string[];
  explanation?: string;
  marks: number;
  difficulty?: string;
  order: number;
}

interface Assessment {
  id: number;
  title: string;
  description: string;
  custom_prompt?: string;
  difficulty_level: string;
  question_types: string[];
  total_questions: number;
  status: string;
  total_marks: number;
  duration_minutes: number;
  course_id: number;
  created_by: number;
  created_at: string;
  questions: Question[];
}

interface ListAssessmentsResponse {
  assessments: Assessment[];
  total: number;
}

interface Attempt {
  id: number;
  assessment_id: number;
  student_id: number;
  score: number;
  max_score: number;
  percentage: number;
  started_at: string;
  submitted_at: string;
  time_taken_minutes: number;
}

interface Feedback {
  id: number;
  target_id: number;
  target_type: string;
  rating: number;
  comment: string;
  user_id: number;
  created_at: string;
}

export default function Assessment() {
  const [activeTab, setActiveTab] = useState<"assessment" | "past" | "feedback">("assessment");
  const [pastSubTab, setPastSubTab] = useState<"assessments" | "attempts">("assessments");

  // Course state
  const [courses, setCourses] = useState<Course[]>([]);
  const [loadingCourses, setLoadingCourses] = useState(false);

  // Inputs - ALL REQUIRED FIELDS
  const [title, setTitle] = useState("Auto-generated Assessment");
  const [description, setDescription] = useState("");
  const [selectedCourseId, setSelectedCourseId] = useState<number>(1);
  const [customPrompt, setCustomPrompt] = useState("");
  const [difficulty, setDifficulty] = useState<"EASY" | "MEDIUM" | "HARD">("MEDIUM");
  const [questionTypes, setQuestionTypes] = useState<string[]>(["MCQ"]);
  const [totalQuestions, setTotalQuestions] = useState(5);
  const [durationMinutes, setDurationMinutes] = useState(30);

  // Backend state
  const [assessmentId, setAssessmentId] = useState<number | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [status, setStatus] = useState<string | null>(null);

  // Past assessments state
  const [pastAssessments, setPastAssessments] = useState<Assessment[]>([]);
  const [attempts, setAttempts] = useState<Attempt[]>([]);
  const [attemptAssessments, setAttemptAssessments] = useState<Record<number, Assessment>>({});
  const [loadingPast, setLoadingPast] = useState(false);
  const [selectedAssessment, setSelectedAssessment] = useState<Assessment | null>(null);
  const [selectedAttempt, setSelectedAttempt] = useState<Attempt | null>(null);

  // Assessment taking states
  const [isTakingAssessment, setIsTakingAssessment] = useState(false);
  const [currentAttempt, setCurrentAttempt] = useState<Attempt | null>(null);
  const [previewAssessment, setPreviewAssessment] = useState<Assessment | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Feedback state
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [loadingFeedbacks, setLoadingFeedbacks] = useState(false);
  const [feedbackRating, setFeedbackRating] = useState(0);
  const [feedbackComment, setFeedbackComment] = useState("");

  const token = typeof window !== "undefined" ? localStorage.getItem("access_token") : null;
  const API_BASE = process.env.NEXT_PUBLIC_API_URL!;

  // Fetch courses on mount
  const fetchCourses = useCallback(async () => {
    if (!token || !API_BASE) return;
    setLoadingCourses(true);
    try {
      const res = await fetch(`${API_BASE}/courses`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data: Course[] = await res.json();
        setCourses(data);
        if (data.length > 0) setSelectedCourseId(data[0].id);
      }
    } catch (err) {
      console.error("Error fetching courses:", err);
    } finally {
      setLoadingCourses(false);
    }
  }, [token, API_BASE]);

  // Fetch feedbacks
  const fetchFeedbacks = useCallback(async () => {
    if (!token || !API_BASE) return;
    setLoadingFeedbacks(true);
    try {
      const res = await fetch(`${API_BASE}/feedback/?target_id=0&target_type=assessment`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data: Feedback[] = await res.json();
        setFeedbacks(data);
      }
    } catch (err) {
      console.error("Error fetching feedbacks:", err);
    } finally {
      setLoadingFeedbacks(false);
    }
  }, [token, API_BASE]);

  useEffect(() => {
    fetchCourses();
  }, [fetchCourses]);

  useEffect(() => {
    if (activeTab === "feedback") {
      fetchFeedbacks();
    }
  }, [activeTab, fetchFeedbacks]);

  const fetchPastAssessments = async () => {
    setLoadingPast(true);
    try {
      const res = await fetch(`${API_BASE}/assessments/`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data: ListAssessmentsResponse = await res.json();
        setPastAssessments(data.assessments);
      }
    } catch (err) {
      console.error("Error fetching past assessments:", err);
    } finally {
      setLoadingPast(false);
    }
  };

  const fetchMyAttempts = async () => {
    setLoadingPast(true);
    try {
      const res = await fetch(`${API_BASE}/assessments/my-attempts`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        const data: Attempt[] = await res.json();
        setAttempts(data);
        const assessmentIds = [...new Set(data.map(attempt => attempt.assessment_id))];
        await fetchAssessmentsForAttempts(assessmentIds);
      }
    } catch (err) {
      console.error("Error fetching my attempts:", err);
    } finally {
      setLoadingPast(false);
    }
  };

  const fetchAssessmentsForAttempts = async (assessmentIds: number[]) => {
    try {
      const assessmentPromises = assessmentIds.map(async (id) => {
        const res = await fetch(`${API_BASE}/assessments/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (res.ok) {
          const data: Assessment = await res.json();
          return { id, assessment: data } as { id: number; assessment: Assessment; };
        }
        return null;
      });

      const results = (await Promise.all(assessmentPromises)).filter(Boolean) as { id: number; assessment: Assessment; }[];
      const newAttemptAssessments: Record<number, Assessment> = {};
      results.forEach((result) => {
        newAttemptAssessments[result.id] = result.assessment;
      });
      setAttemptAssessments(prev => ({ ...prev, ...newAttemptAssessments }));
    } catch (err) {
      console.error("Error fetching assessment details for attempts:", err);
    }
  };

  useEffect(() => {
    if (activeTab === "past") {
      setSelectedAssessment(null);
      setSelectedAttempt(null);
      if (pastSubTab === "assessments") {
        fetchPastAssessments();
      } else {
        fetchMyAttempts();
      }
    }
  }, [activeTab, pastSubTab]);

  const generateAssessment = async () => {
    if (!token || !API_BASE) {
      alert("Missing authentication or API URL");
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/assessments/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          title,
          description: description || `AI-generated assessment for ${title}`,
          course_id: selectedCourseId,
          custom_prompt: customPrompt || `Generate ${totalQuestions} ${difficulty.toLowerCase()} ${questionTypes.join(', ')} questions`,
          difficulty_level: difficulty,
          question_types: questionTypes,
          total_questions: totalQuestions,
          reference_document_ids: [],
          duration_minutes: durationMinutes,
        }),
      });

      const data = await res.json();

      if (res.status === 201) {
        setAssessmentId(data.id);
        setStatus(data.status);
        setQuestions([]);
        setTitle("Auto-generated Assessment");
        setDescription("");
        setCustomPrompt("");
      } else {
        alert("Error creating assessment: " + (data?.detail?.[0]?.msg || data?.detail || "Unknown error"));
      }
    } catch (err) {
      console.error("Error:", err);
      alert("Failed to create assessment");
    }
  };

  useEffect(() => {
    if (!assessmentId || !token || !API_BASE) return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch(`${API_BASE}/assessments/${assessmentId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const data = await res.json();

        setStatus(data.status);

        if (data.status !== "GENERATING") {
          clearInterval(interval);
        }
        if (data.status === "COMPLETED") {
          setQuestions(data.questions || []);
        }
        if (data.status === "FAILED") {
          alert("Assessment generation failed.");
        }
      } catch (err) {
        console.error("Polling error:", err);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [assessmentId, token, API_BASE]);

  const startAssessment = useCallback(async (assessmentId: number) => {
    if (!token || !API_BASE || !previewAssessment) return;

    try {
      const res = await fetch(`${API_BASE}/assessments/${assessmentId}/attempts`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });

      if (res.ok) {
        const attempt: Attempt = await res.json();
        setCurrentAttempt(attempt);
        setTimeLeft(previewAssessment.duration_minutes * 60);
        setIsTakingAssessment(true);

        timerRef.current = setInterval(() => {
          setTimeLeft((prev) => {
            if (prev <= 1) {
              if (timerRef.current) clearInterval(timerRef.current);
              if (attempt.id) submitAssessment(attempt.id);
              return 0;
            }
            return prev - 1;
          });
        }, 1000);
      }
    } catch (err) {
      console.error("Start assessment error:", err);
      alert("Failed to start assessment");
    }
  }, [token, API_BASE, previewAssessment]);

  const submitAssessment = useCallback(async (attemptId: number) => {
    if (!token || !API_BASE) return;

    try {
      await fetch(`${API_BASE}/assessments/attempts/${attemptId}/submit`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          answers: Object.entries(userAnswers).map(([qId, ans]) => ({
            question_id: Number(qId),
            answer: ans,
          })),
        }),
      });

      setIsTakingAssessment(false);
      setCurrentAttempt(null);
      setPreviewAssessment(null);
      setUserAnswers({});
      setTimeLeft(0);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }

      fetchMyAttempts();
      alert("Assessment submitted successfully!");
    } catch (err) {
      console.error("Submit error:", err);
      alert("Failed to submit assessment");
    }
  }, [userAnswers, token, API_BASE, fetchMyAttempts]);

  const selectAnswer = (questionId: number, answer: string) => {
    setUserAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const cancelAssessment = () => {
    setIsTakingAssessment(false);
    setPreviewAssessment(null);
    setCurrentAttempt(null);
    setUserAnswers({});
    setTimeLeft(0);
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const submitFeedback = async () => {
    if (!token || !API_BASE) {
      alert("Missing authentication or API URL");
      return;
    }

    if (feedbackRating === 0) {
      alert("Please provide a rating");
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/feedback/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          target_id: 0,
          target_type: "assessment",
          rating: feedbackRating,
          comment: feedbackComment || "",
        }),
      });

      if (res.ok) {
        alert("Feedback submitted successfully!");
        // Reset form
        setFeedbackRating(0);
        setFeedbackComment("");
        // Refresh feedbacks
        fetchFeedbacks();
      } else {
        const data = await res.json();
        alert("Error submitting feedback: " + (data?.detail || "Unknown error"));
      }
    } catch (err) {
      console.error("Error submitting feedback:", err);
      alert("Failed to submit feedback");
    }
  };

  const getAssessmentTitle = (assessmentId: number) => {
    const assessment = pastAssessments.find(a => a.id === assessmentId) ||
      attemptAssessments[assessmentId];
    return assessment?.title || `Assessment #${assessmentId}`;
  };

  const toggleQuestionType = (type: string) => {
    setQuestionTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, []);

  return (
    <AppLayout>
      <div className="flex flex-1">
        {/* Sidebar */}
        <div className="flex flex-col w-80 bg-neutral-50 p-4">
          <h1 className="text-lg font-semibold mb-4">Assessment Generator</h1>
          <button
            onClick={() => setActiveTab("assessment")}
            className={`px-3 py-2 rounded-lg ${activeTab === "assessment" ? "bg-[#ededed]" : ""}`}
          >
            Generate Assessment
          </button>
          <button
            onClick={() => {
              setActiveTab("past");
              setPastSubTab("assessments");
            }}
            className={`px-3 py-2 rounded-lg mt-2 ${activeTab === "past" ? "bg-[#ededed]" : ""}`}
          >
            Past Assessments
          </button>
          <button
            onClick={() => setActiveTab("feedback")}
            className={`px-3 py-2 rounded-lg mt-2 ${activeTab === "feedback" ? "bg-[#ededed]" : ""}`}
          >
            Collect Feedback
          </button>
        </div>

        {/* Main Content */}
        <div className="flex-1 p-4">
          {activeTab === "assessment" ? (
            <>
              <h1 className="text-[32px] font-bold mb-6">Automated Assessment Generator</h1>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8 max-w-4xl">
                <label className="block">
                  <p className="font-semibold mb-2">Title *</p>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g., DBMS Midterm Assessment"
                    className="w-full border rounded-lg p-3 bg-neutral-50 focus:ring-2 focus:ring-blue-500"
                  />
                </label>

                <label className="block">
                  <p className="font-semibold mb-2">Course *</p>
                  <select
                    value={selectedCourseId}
                    onChange={(e) => setSelectedCourseId(Number(e.target.value))}
                    disabled={loadingCourses}
                    className="w-full border rounded-lg p-3 bg-neutral-50 focus:ring-2 focus:ring-blue-500"
                  >
                    {loadingCourses ? (
                      <option>Loading courses...</option>
                    ) : courses.map((course) => (
                      <option key={course.id} value={course.id}>
                        {course.code} - {course.name}
                      </option>
                    ))}
                  </select>
                </label>

                <label className="md:col-span-2 block">
                  <p className="font-semibold mb-2">Description</p>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Brief description of the assessment..."
                    rows={3}
                    className="w-full border rounded-lg p-3 bg-neutral-50 focus:ring-2 focus:ring-blue-500"
                  />
                </label>

                <label className="md:col-span-2 block">
                  <p className="font-semibold mb-2">Custom Prompt (Optional)</p>
                  <textarea
                    value={customPrompt}
                    onChange={(e) => setCustomPrompt(e.target.value)}
                    placeholder="Be specific about topics, difficulty, and question types"
                    rows={3}
                    className="w-full border rounded-lg p-3 bg-neutral-50 focus:ring-2 focus:ring-blue-500"
                  />
                  <p className="text-xs text-neutral-500 mt-1">Leave empty for auto-generated prompt</p>
                </label>

                <label className="block">
                  <p className="font-semibold mb-2">Difficulty Level *</p>
                  <select
                    value={difficulty}
                    onChange={(e) => setDifficulty(e.target.value as "EASY" | "MEDIUM" | "HARD")}
                    className="w-full border rounded-lg p-3 bg-neutral-50 focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="EASY">Easy</option>
                    <option value="MEDIUM">Medium</option>
                    <option value="HARD">Hard</option>
                  </select>
                </label>

                <label className="block">
                  <p className="font-semibold mb-2">Question Types *</p>
                  <div className="flex flex-wrap gap-2">
                    {["MCQ", "MSQ", "NAT"].map((type) => (
                      <button
                        key={type}
                        type="button"
                        onClick={() => toggleQuestionType(type)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${questionTypes.includes(type)
                          ? "bg-blue-500 text-white shadow-lg"
                          : "bg-neutral-200 hover:bg-neutral-300"
                          }`}
                      >
                        {type}
                      </button>
                    ))}
                  </div>
                  <p className="text-xs text-neutral-500 mt-1">Selected: {questionTypes.join(", ")}</p>
                </label>

                <label className="block">
                  <p className="font-semibold mb-2">Total Questions *</p>
                  <input
                    type="number"
                    min={1}
                    max={50}
                    value={totalQuestions}
                    onChange={(e) => setTotalQuestions(Number(e.target.value))}
                    className="w-full border rounded-lg p-3 bg-neutral-50 focus:ring-2 focus:ring-blue-500"
                  />
                </label>

                <label className="block">
                  <p className="font-semibold mb-2">Duration (minutes) *</p>
                  <input
                    type="number"
                    min={5}
                    max={180}
                    value={durationMinutes}
                    onChange={(e) => setDurationMinutes(Number(e.target.value))}
                    className="w-full border rounded-lg p-3 bg-neutral-50 focus:ring-2 focus:ring-blue-500"
                  />
                </label>
              </div>

              <button
                onClick={generateAssessment}
                disabled={!questionTypes.length || !selectedCourseId || totalQuestions < 1}
                className="bg-black text-white px-8 py-4 rounded-xl font-bold text-lg hover:bg-neutral-900 disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transition-all"
              >
                Generate Assessment
              </button>

              {assessmentId && (
                <div className="mt-6 p-6 bg-neutral-50 rounded-xl border">
                  <p className="text-sm text-neutral-600 mb-2">
                    Status: <span className="font-bold text-lg">{status}</span>
                  </p>
                  {status === "GENERATING" && (
                    <div className="flex items-center gap-2 text-blue-600">
                      <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
                      Generating questions...
                    </div>
                  )}
                </div>
              )}

              {questions.length > 0 && (
                <>
                  <h3 className="text-lg font-bold mt-8 mb-4">Generated Questions</h3>
                  <div className="rounded-lg border bg-neutral-50 overflow-hidden">
                    <table className="w-full">
                      <thead>
                        <tr className="bg-neutral-100">
                          <th className="px-4 py-3 text-left">Question</th>
                          <th className="px-4 py-3 text-left w-20">Type</th>
                          <th className="px-4 py-3 text-left w-20">Marks</th>
                        </tr>
                      </thead>
                      <tbody>
                        {questions.map((q, idx) => (
                          <tr key={q.id || idx} className="border-t hover:bg-neutral-100">
                            <td className="px-4 py-4">{q.question_text}</td>
                            <td className="px-4 py-4">
                              <span className="px-2 py-1 bg-neutral-200 text-neutral-800 text-xs rounded font-medium">
                                {q.question_type}
                              </span>
                            </td>
                            <td className="px-4 py-4 font-semibold">{q.marks}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </>
              )}
            </>
          ) : activeTab === "past" ? (
            <>
              <div className="flex mb-6">
                <button
                  onClick={() => setPastSubTab("assessments")}
                  className={`px-6 py-2 rounded-lg font-semibold mr-2 ${pastSubTab === "assessments"
                    ? "bg-black text-white"
                    : "bg-neutral-200 hover:bg-neutral-300"
                    }`}
                >
                  My Assessments
                </button>
                <button
                  onClick={() => setPastSubTab("attempts")}
                  className={`px-6 py-2 rounded-lg font-semibold ${pastSubTab === "attempts"
                    ? "bg-black text-white"
                    : "bg-neutral-200 hover:bg-neutral-300"
                    }`}
                >
                  My Attempts
                </button>
              </div>

              {/* TAKING ASSESSMENT MODE */}
              {isTakingAssessment && currentAttempt && previewAssessment && (
                <div className="max-w-4xl mx-auto space-y-6">
                  <div className="flex justify-between items-center bg-black text-white p-6 rounded-lg">
                    <div>
                      <div className="text-sm text-neutral-300">Time remaining</div>
                      <div className="text-3xl font-bold">
                        {Math.floor(timeLeft / 60)}:{(timeLeft % 60).toString().padStart(2, '0')}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-bold">
                        Q {Object.keys(userAnswers).length} / {previewAssessment.total_questions}
                      </div>
                      <div className="text-sm text-neutral-300">{previewAssessment.title}</div>
                    </div>
                  </div>

                  <div className="space-y-6">
                    {previewAssessment.questions.map((q, idx) => (
                      <div key={q.id} className="bg-white rounded-lg border p-6">
                        <div className="flex justify-between items-start mb-4">
                          <h3 className="text-lg font-bold text-neutral-900">
                            {idx + 1}. {q.question_text}
                          </h3>
                          <span className="text-lg font-bold text-neutral-600">{q.marks} marks</span>
                        </div>

                        <div className="space-y-2">
                          {q.options.map((option, optIdx) => (
                            <button
                              key={optIdx}
                              onClick={() => selectAnswer(q.id, option)}
                              className={`w-full p-3 rounded-lg border text-left transition-all ${userAnswers[q.id] === option
                                ? 'bg-black border-black text-white'
                                : 'bg-neutral-50 border-neutral-200 hover:border-neutral-400 hover:bg-neutral-100'
                                }`}
                            >
                              {option}
                            </button>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-4 pt-6 border-t">
                    <button
                      onClick={() => currentAttempt && submitAssessment(currentAttempt.id)}
                      disabled={Object.keys(userAnswers).length < previewAssessment!.total_questions}
                      className="flex-1 bg-black hover:bg-neutral-800 text-white py-4 px-8 rounded-lg font-bold text-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      Submit Assessment
                    </button>
                    <button
                      onClick={cancelAssessment}
                      className="px-8 py-4 bg-neutral-200 hover:bg-neutral-300 border border-neutral-300 rounded-lg font-bold transition-all"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}

              {/* PREVIEW MODE */}
              {previewAssessment && !isTakingAssessment && (
                <div className="max-w-4xl mx-auto">
                  <div className="flex items-center gap-3 mb-6">
                    <button
                      onClick={() => {
                        setPreviewAssessment(null);
                        setSelectedAssessment(null);
                      }}
                      className="text-sm text-neutral-600 hover:text-black flex items-center gap-1"
                    >
                      ← Back to list
                    </button>
                  </div>

                  <div className="bg-white rounded-lg border p-8 mb-6">
                    <h1 className="text-3xl font-bold mb-2">{previewAssessment.title}</h1>
                    <p className="text-neutral-600 mb-8">{previewAssessment.description}</p>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                      <div className="bg-neutral-50 p-4 rounded-lg text-center border">
                        <div className="text-2xl font-bold text-neutral-900">{previewAssessment.total_questions}</div>
                        <div className="text-sm text-neutral-600 mt-1">Questions</div>
                      </div>
                      <div className="bg-neutral-50 p-4 rounded-lg text-center border">
                        <div className="text-2xl font-bold text-neutral-900">{previewAssessment.total_marks}</div>
                        <div className="text-sm text-neutral-600 mt-1">Total Marks</div>
                      </div>
                      <div className="bg-neutral-50 p-4 rounded-lg text-center border">
                        <div className="text-2xl font-bold text-neutral-900">{previewAssessment.duration_minutes}</div>
                        <div className="text-sm text-neutral-600 mt-1">Minutes</div>
                      </div>
                      <div className="bg-neutral-50 p-4 rounded-lg text-center border">
                        <div className="text-2xl font-bold text-neutral-900">{previewAssessment.difficulty_level || 'N/A'}</div>
                        <div className="text-sm text-neutral-600 mt-1">Difficulty</div>
                      </div>
                    </div>

                    <div className="flex gap-4">
                      <button
                        onClick={() => previewAssessment && startAssessment(previewAssessment.id)}
                        className="flex-1 bg-black hover:bg-neutral-800 text-white py-4 px-8 rounded-lg font-bold text-lg transition-all"
                      >
                        Start Assessment
                      </button>
                      <button
                        onClick={() => setPreviewAssessment(null)}
                        className="px-8 py-4 bg-neutral-200 hover:bg-neutral-300 border border-neutral-300 rounded-lg font-bold transition-all"
                      >
                        Close Preview
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* ASSESSMENTS LIST */}
              {pastSubTab === "assessments" && !selectedAssessment && !previewAssessment && !isTakingAssessment && (
                <>
                  <h1 className="text-[32px] font-bold mb-6">Past Assessments</h1>
                  {loadingPast ? (
                    <p className="text-neutral-500">Loading assessments...</p>
                  ) : (
                    <div className="mt-3 rounded-lg border bg-neutral-50 overflow-hidden">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-neutral-100">
                            <th className="px-4 py-3 text-left">Title</th>
                            <th className="px-4 py-3 text-left">Difficulty</th>
                            <th className="px-4 py-3 text-left">Questions</th>
                            <th className="px-4 py-3 text-left">Marks</th>
                            <th className="px-4 py-3 text-left">Duration</th>
                            <th className="px-4 py-3 text-left">Status</th>
                            <th className="px-4 py-3 text-left">Created</th>
                            <th className="px-4 py-3 text-left">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {pastAssessments.length === 0 ? (
                            <tr>
                              <td colSpan={8} className="p-4 text-neutral-500">
                                No past assessments found.
                              </td>
                            </tr>
                          ) : (
                            pastAssessments.map((assessment) => (
                              <tr key={assessment.id} className="border-t hover:bg-neutral-100 cursor-pointer">
                                <td
                                  className="px-4 py-3 font-medium max-w-xs truncate"
                                  onClick={() => setSelectedAssessment(assessment)}
                                >
                                  {assessment.title}
                                </td>
                                <td className="px-4 py-3">{assessment.difficulty_level}</td>
                                <td className="px-4 py-3">{assessment.total_questions}</td>
                                <td className="px-4 py-3">{assessment.total_marks}</td>
                                <td className="px-4 py-3">{assessment.duration_minutes} mins</td>
                                <td className="px-4 py-3">
                                  <span className={`px-2 py-1 rounded text-xs font-semibold ${assessment.status === "COMPLETED" ? "bg-green-100 text-green-800" :
                                    assessment.status === "GENERATING" ? "bg-yellow-100 text-yellow-800" :
                                      "bg-red-100 text-red-800"
                                    }`}>
                                    {assessment.status}
                                  </span>
                                </td>
                                <td className="px-4 py-3">
                                  {new Date(assessment.created_at).toLocaleDateString()}
                                </td>
                                <td className="px-4 py-3">
                                  <button
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      setPreviewAssessment(assessment);
                                      setUserAnswers({});
                                      setIsTakingAssessment(false);
                                    }}
                                    className="text-blue-600 hover:text-blue-800 hover:underline text-sm font-medium"
                                  >
                                    Preview
                                  </button>
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}
                </>
              )}

              {/* SELECTED ASSESSMENT DETAIL VIEW */}
              {selectedAssessment && !previewAssessment && !isTakingAssessment && (
                <div>
                  <div className="flex items-center gap-3 mb-6">
                    <button
                      onClick={() => setSelectedAssessment(null)}
                      className="text-sm text-neutral-600 hover:text-black flex items-center gap-1"
                    >
                      ← Back to list
                    </button>
                  </div>

                  <div className="bg-white rounded-lg border p-6 mb-6">
                    <div className="flex justify-between items-start mb-4">
                      <div>
                        <h1 className="text-2xl font-bold mb-2">{selectedAssessment.title}</h1>
                        <p className="text-neutral-600 mb-4">{selectedAssessment.description}</p>
                      </div>
                      <button
                        onClick={() => {
                          setPreviewAssessment(selectedAssessment);
                          setUserAnswers({});
                          setIsTakingAssessment(false);
                        }}
                        className="bg-black text-white px-6 py-3 rounded-lg font-bold hover:bg-neutral-800"
                      >
                        Preview Assessment
                      </button>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-6">
                      <div className="bg-neutral-50 p-3 rounded-lg border">
                        <div className="text-sm text-neutral-600">Questions</div>
                        <div className="text-xl font-bold">{selectedAssessment.total_questions}</div>
                      </div>
                      <div className="bg-neutral-50 p-3 rounded-lg border">
                        <div className="text-sm text-neutral-600">Total Marks</div>
                        <div className="text-xl font-bold">{selectedAssessment.total_marks}</div>
                      </div>
                      <div className="bg-neutral-50 p-3 rounded-lg border">
                        <div className="text-sm text-neutral-600">Duration</div>
                        <div className="text-xl font-bold">{selectedAssessment.duration_minutes} min</div>
                      </div>
                      <div className="bg-neutral-50 p-3 rounded-lg border">
                        <div className="text-sm text-neutral-600">Difficulty</div>
                        <div className="text-xl font-bold">{selectedAssessment.difficulty_level}</div>
                      </div>
                      <div className="bg-neutral-50 p-3 rounded-lg border">
                        <div className="text-sm text-neutral-600">Status</div>
                        <div className="text-xl font-bold">{selectedAssessment.status}</div>
                      </div>
                    </div>
                  </div>

                  <h2 className="text-xl font-bold mb-4">Questions ({selectedAssessment.questions.length})</h2>
                  <div className="space-y-4">
                    {selectedAssessment.questions.map((q, idx) => (
                      <div key={q.id} className="bg-white rounded-lg border p-6">
                        <div className="flex justify-between items-start mb-4">
                          <h3 className="text-lg font-bold">
                            {idx + 1}. {q.question_text}
                          </h3>
                          <div className="flex gap-2 items-center">
                            <span className="px-2 py-1 bg-neutral-200 text-neutral-800 text-xs rounded font-medium">
                              {q.question_type}
                            </span>
                            <span className="text-lg font-bold text-neutral-600">{q.marks} marks</span>
                          </div>
                        </div>

                        <div className="space-y-2 mb-4">
                          {q.options.map((option, optIdx) => (
                            <div
                              key={optIdx}
                              className={`p-3 rounded-lg border ${q.correct_answer?.includes(option.charAt(0))
                                ? 'bg-green-50 border-green-200'
                                : 'bg-neutral-50 border-neutral-200'
                                }`}
                            >
                              {option}
                              {q.correct_answer?.includes(option.charAt(0)) && (
                                <span className="ml-2 text-green-600 font-semibold">✓ Correct</span>
                              )}
                            </div>
                          ))}
                        </div>

                        {q.explanation && (
                          <div className="bg-neutral-50 p-4 rounded-lg border">
                            <p className="text-sm font-semibold text-neutral-700 mb-1">Explanation:</p>
                            <p className="text-sm text-neutral-600">{q.explanation}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* ATTEMPTS TAB */}
              {pastSubTab === "attempts" && !selectedAttempt && !previewAssessment && !isTakingAssessment && (
                <>
                  <h1 className="text-[32px] font-bold mb-6">My Assessment Attempts</h1>
                  {loadingPast ? (
                    <p className="text-neutral-500">Loading attempts...</p>
                  ) : (
                    <div className="mt-3 rounded-lg border bg-neutral-50 overflow-hidden">
                      <table className="w-full">
                        <thead>
                          <tr className="bg-neutral-100">
                            <th className="px-4 py-3 text-left">Attempt ID</th>
                            <th className="px-4 py-3 text-left">Assessment</th>
                            <th className="px-4 py-3 text-left">Score</th>
                            <th className="px-4 py-3 text-left">Percentage</th>
                            <th className="px-4 py-3 text-left">Time Taken</th>
                            <th className="px-4 py-3 text-left">Submitted</th>
                          </tr>
                        </thead>
                        <tbody>
                          {attempts.length === 0 ? (
                            <tr>
                              <td colSpan={6} className="p-4 text-neutral-500">No attempts found.</td>
                            </tr>
                          ) : (
                            attempts.map((attempt) => (
                              <tr key={attempt.id} className="border-t hover:bg-neutral-100 cursor-pointer">
                                <td className="px-4 py-3 font-mono text-sm">#{attempt.id}</td>
                                <td className="px-4 py-3 font-medium max-w-xs truncate">
                                  {getAssessmentTitle(attempt.assessment_id)}
                                </td>
                                <td className="px-4 py-3">
                                  <span className="font-bold text-lg">{attempt.score}/{attempt.max_score}</span>
                                </td>
                                <td className="px-4 py-3">
                                  <span className="px-3 py-1 bg-neutral-200 rounded-full text-sm font-semibold">
                                    {attempt.percentage.toFixed(0)}%
                                  </span>
                                </td>
                                <td className="px-4 py-3">{attempt.time_taken_minutes} mins</td>
                                <td className="px-4 py-3">
                                  {new Date(attempt.submitted_at).toLocaleDateString()}
                                </td>
                              </tr>
                            ))
                          )}
                        </tbody>
                      </table>
                    </div>
                  )}
                </>
              )}
            </>
          ) : activeTab === "feedback" ? (
            <>
              <h1 className="text-[32px] font-bold mb-6">Assessment Feedback</h1>

              {/* Submit Feedback Form */}
              <div className="max-w-3xl mb-12">
                <h2 className="text-xl font-bold mb-4">Submit Your Feedback</h2>

                <div className="mb-6 p-6 bg-neutral-50 rounded-lg border">
                  <h3 className="text-lg font-semibold mb-4">How would you rate the assessments?</h3>
                  <div className="flex gap-2">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        type="button"
                        onClick={() => setFeedbackRating(star)}
                        className={`p-3 rounded-lg transition-all text-sm font-bold ${feedbackRating >= star
                          ? 'bg-black text-white'
                          : 'bg-neutral-200 hover:bg-neutral-300 text-neutral-700'
                          }`}
                      >
                        ⭐ {star}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="mb-6">
                  <label className="block">
                    <p className="font-semibold mb-2">Comments (Optional)</p>
                    <textarea
                      value={feedbackComment}
                      onChange={(e) => setFeedbackComment(e.target.value)}
                      placeholder="Share your thoughts about the assessments..."
                      rows={4}
                      className="w-full border rounded-lg p-3 bg-white"
                    />
                  </label>
                </div>

                <button
                  onClick={submitFeedback}
                  className="bg-black text-white px-8 py-4 rounded-lg font-bold text-lg hover:bg-neutral-900 transition-all"
                >
                  Submit Feedback
                </button>
              </div>

              {/* Display All Feedbacks */}
              <div>
                <h2 className="text-xl font-bold mb-4">All Feedback ({feedbacks.length})</h2>
                {loadingFeedbacks ? (
                  <p className="text-neutral-500">Loading feedbacks...</p>
                ) : feedbacks.length === 0 ? (
                  <div className="bg-neutral-50 border rounded-lg p-8 text-center text-neutral-500">
                    No feedback submitted yet. Be the first to share your thoughts!
                  </div>
                ) : (
                  <div className="space-y-4">
                    {feedbacks.map((feedback) => (
                      <div key={feedback.id} className="bg-white border rounded-lg p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <div className="flex items-center gap-2 mb-2">
                              <span className="font-semibold">User #{feedback.user_id}</span>
                              <span className="text-sm text-neutral-500">
                                {new Date(feedback.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            <div className="flex items-center gap-1">
                              <span className="font-semibold">Rating:</span>
                              <span className="text-xl">{'⭐'.repeat(feedback.rating)}</span>
                              <span className="text-neutral-500">({feedback.rating}/5)</span>
                            </div>
                          </div>
                        </div>

                        {/* Comment */}
                        {feedback.comment && (
                          <div className="bg-neutral-50 p-4 rounded-lg border">
                            <p className="text-sm text-neutral-600">{feedback.comment}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          ) : null}
        </div>
      </div>
    </AppLayout>
  );
}
