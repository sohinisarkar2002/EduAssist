"use client";

import AppLayout from "@/components/AppLayout";
import { useState, useEffect, useRef } from "react";
import ReactMarkdown from "react-markdown";

interface Slide {
  id: number;
  title: string;
  content_md: string;
  notes_md: string;
  image_url: string;
  position: number;
}

interface SlideDeck {
  id: number;
  title: string;
  status: string;
  slides: Slide[];
  created_at: string;
}

interface Doc {
  id: number;
  title: string;
  file_path: string;
  file_type: string;
  file_size: number;
  processed: boolean;
  course_id: number;
  uploaded_by: number;
  uploaded_at: string;
}

interface Feedback {
  id: number;
  target_id: number;
  target_type: string;
  rating: number;
  aspect_ratings?: Record<string, number>;
  comment: string;
  user_id: number;
  created_at: string;
}

const FALLBACK_IMAGES = [
  "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=800&h=600&fit=crop",
  "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800&h=600&fit=crop",
  "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=800&h=600&fit=crop",
  "https://images.unsplash.com/photo-1486312338219-ce68d2c6f44d?w=800&h=600&fit=crop",
];

const SlideImage = ({
  src,
  alt,
  index,
}: {
  src: string;
  alt: string;
  index: number;
}) => {
  const [imgSrc, setImgSrc] = useState(
    src || FALLBACK_IMAGES[index % FALLBACK_IMAGES.length]
  );
  const [isLoading, setIsLoading] = useState(true);
  const imgRef = useRef<HTMLImageElement>(null);

  const handleError = () => {
    setImgSrc(FALLBACK_IMAGES[index % FALLBACK_IMAGES.length]);
    setIsLoading(false);
  };

  const handleLoad = (e: React.SyntheticEvent<HTMLImageElement>) => {
    const img = e.currentTarget;

    const isImgurPlaceholder =
      (img.naturalWidth === 161 && img.naturalHeight === 81) ||
      (img.naturalWidth < 200 &&
        img.naturalHeight < 100 &&
        src.includes("imgur")) ||
      img.src.includes("removed.png");

    if (isImgurPlaceholder) {
      setImgSrc(FALLBACK_IMAGES[index % FALLBACK_IMAGES.length]);
    }

    setIsLoading(false);
  };

  return (
    <div className="relative w-full h-full bg-neutral-200 rounded-lg overflow-hidden flex items-center justify-center">
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center z-10">
          <div className="w-8 h-8 border-2 border-neutral-400 border-t-transparent rounded-full animate-spin" />
        </div>
      )}
      <img
        ref={imgRef}
        src={imgSrc}
        alt={alt}
        onError={handleError}
        onLoad={handleLoad}
        className="w-full h-full object-cover"
      />
    </div>
  );
};

interface PresenterModeProps {
  slides: Slide[];
  deckTitle: string;
  onClose: () => void;
}

const PresenterMode = ({
  slides,
  deckTitle,
  onClose,
}: PresenterModeProps) => {
  const [currentSlideIndex, setCurrentSlideIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const currentSlide = slides[currentSlideIndex];

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" || e.key === " ") {
        e.preventDefault();
        setCurrentSlideIndex((prev) => Math.min(prev + 1, slides.length - 1));
      } else if (e.key === "ArrowLeft") {
        e.preventDefault();
        setCurrentSlideIndex((prev) => Math.max(prev - 1, 0));
      } else if (e.key === "Escape") {
        e.preventDefault();
        onClose();
      }
    };

    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [slides.length, onClose]);

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 w-full h-full bg-gradient-to-br from-neutral-900 to-neutral-800 flex flex-col overflow-hidden"
    >
      <div className="flex-1 flex items-center justify-center p-8 md:p-12 overflow-auto">
        <div className="w-full max-w-6xl">
          <div className="bg-white rounded-2xl shadow-2xl p-6 md:p-12">
            <div className="mb-8 h-[260px] md:h-[360px] lg:h-[420px]">
              <SlideImage
                src={currentSlide.image_url}
                alt={currentSlide.title}
                index={currentSlideIndex}
              />
            </div>

            <h1 className="text-2xl md:text-4xl font-bold mb-6 text-neutral-900">
              {currentSlide.title}
            </h1>

            <div className="prose prose-lg max-w-none text-neutral-700">
              <ReactMarkdown>{currentSlide.content_md}</ReactMarkdown>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-neutral-900 border-t border-neutral-700 p-4 md:p-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div className="text-white text-sm font-medium">
            {deckTitle} · Slide {currentSlideIndex + 1} of {slides.length}
          </div>

          <div className="flex items-center gap-4">
            <button
              onClick={() =>
                setCurrentSlideIndex((prev) => Math.max(prev - 1, 0))
              }
              disabled={currentSlideIndex === 0}
              className="px-3 md:px-4 py-2 bg-neutral-700 text-white rounded-lg hover:bg-neutral-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
            >
              ← Previous
            </button>

            <button
              onClick={() =>
                setCurrentSlideIndex((prev) =>
                  Math.min(prev + 1, slides.length - 1)
                )
              }
              disabled={currentSlideIndex === slides.length - 1}
              className="px-3 md:px-4 py-2 bg-neutral-700 text-white rounded-lg hover:bg-neutral-600 disabled:opacity-50 disabled:cursor-not-allowed transition-colors text-sm"
            >
              Next →
            </button>

            <button
              onClick={onClose}
              className="px-3 md:px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm"
            >
              Exit (Esc)
            </button>
          </div>

          <div className="w-full md:flex-1 md:mx-8 h-1 bg-neutral-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-blue-500 transition-all duration-300"
              style={{
                width: `${((currentSlideIndex + 1) / slides.length) * 100}%`,
              }}
            />
          </div>
        </div>
      </div>

      {currentSlide.notes_md && (
        <div className="bg-neutral-800 border-t border-neutral-700 p-4 md:p-6 max-h-40 overflow-y-auto">
          <p className="text-white text-xs font-semibold mb-2 opacity-70">
            SPEAKER NOTES
          </p>
          <p className="text-white text-sm leading-relaxed whitespace-pre-wrap">
            {currentSlide.notes_md}
          </p>
        </div>
      )}
    </div>
  );
};

export default function SlideCreator() {
  const [activeTab, setActiveTab] = useState<
    "generator" | "feedback" | "past"
  >("generator");

  const [title, setTitle] = useState("");
  const [numSlides, setNumSlides] = useState(10);
  const [depth, setDepth] = useState<"summary" | "detailed">("summary");

  const [deckId, setDeckId] = useState<number | null>(null);
  const [status, setStatus] = useState<string | null>(null);
  const [slides, setSlides] = useState<Slide[]>([]);

  const [loading, setLoading] = useState(false);
  const [refreshingDeck, setRefreshingDeck] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const [pastDecks, setPastDecks] = useState<SlideDeck[]>([]);
  const [loadingPast, setLoadingPast] = useState(false);
  const [selectedDeck, setSelectedDeck] = useState<SlideDeck | null>(null);

  const [docs, setDocs] = useState<Doc[]>([]);
  const [loadingDocs, setLoadingDocs] = useState(false);
  const [selectedDocIds, setSelectedDocIds] = useState<number[]>([]);

  const [presenterDeck, setPresenterDeck] = useState<SlideDeck | null>(null);

  // Feedback state
  const [feedbackRating, setFeedbackRating] = useState<number | null>(null);
  const [feedbackComment, setFeedbackComment] = useState("");
  const [submittingFeedback, setSubmittingFeedback] = useState(false);
  const [feedbackList, setFeedbackList] = useState<Feedback[]>([]);
  const [loadingFeedback, setLoadingFeedback] = useState(false);
  const [feedbackMessage, setFeedbackMessage] = useState<string | null>(null);

  const API_BASE = process.env.NEXT_PUBLIC_API_URL;
  const token =
    typeof window !== "undefined" ? localStorage.getItem("access_token") : null;

  const fetchDocuments = async () => {
    setLoadingDocs(true);
    try {
      const res = await fetch(`${API_BASE}/knowledge/documents`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      if (!res.ok) throw new Error("Failed to fetch documents");
      const data: Doc[] = await res.json();
      setDocs(data);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingDocs(false);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, []);

  const generateDeck = async () => {
    if (!title.trim()) {
      setErrorMessage("Please enter a title.");
      return;
    }

    setErrorMessage(null);
    setLoading(true);
    try {
      const body = {
        title: title.trim(),
        controls: {
          num_slides: numSlides,
          desired_depth: depth,
        },
        reference_document_ids: selectedDocIds,
      };

      const res = await fetch(`${API_BASE}/slide-decks/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(body),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Failed to start deck");
      }

      const data: SlideDeck = await res.json();
      setDeckId(data.id);
      setStatus(data.status);
      setSlides([]);
    } catch (e) {
      console.error(e);
      setErrorMessage(
        e instanceof Error ? e.message : "Failed to start slide generation."
      );
    } finally {
      setLoading(false);
    }
  };

  const refreshDeckStatus = async () => {
    if (!deckId) return;
    setRefreshingDeck(true);
    try {
      const res = await fetch(`${API_BASE}/slide-decks/${deckId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to fetch deck");
      const data: SlideDeck = await res.json();
      setStatus(data.status);
      setSlides(data.slides || []);
    } catch (e) {
      console.error(e);
      setErrorMessage(
        e instanceof Error ? e.message : "Failed to refresh slide deck."
      );
    } finally {
      setRefreshingDeck(false);
    }
  };

  const fetchPastDecks = async () => {
    setLoadingPast(true);
    try {
      const res = await fetch(`${API_BASE}/slide-decks/`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) throw new Error("Failed to fetch past decks");
      const data: SlideDeck[] = await res.json();
      setPastDecks(data);
    } catch (e) {
      console.error(e);
      setErrorMessage("Failed to load past decks.");
    } finally {
      setLoadingPast(false);
    }
  };

  // Fetch feedback
  const fetchFeedback = async () => {
    setLoadingFeedback(true);
    setFeedbackMessage(null);
    try {
      const res = await fetch(
        `${API_BASE}/feedback/?target_id=2&target_type=slide_deck`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      if (!res.ok) throw new Error("Failed to fetch feedback");
      const data: Feedback[] = await res.json();
      setFeedbackList(data);
    } catch (e) {
      console.error(e);
      setFeedbackMessage("Failed to load feedback.");
    } finally {
      setLoadingFeedback(false);
    }
  };

  // Submit feedback
  const submitFeedback = async () => {
    if (!feedbackRating) {
      setFeedbackMessage("Please select a rating.");
      return;
    }

    setSubmittingFeedback(true);
    setFeedbackMessage(null);

    try {
      const res = await fetch(`${API_BASE}/feedback/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          target_id: 2,
          target_type: "slide_deck",
          rating: feedbackRating,
          comment: feedbackComment.trim() || "",
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.detail || "Failed to submit feedback");
      }

      setFeedbackMessage("✓ Feedback submitted successfully!");
      setFeedbackRating(null);
      setFeedbackComment("");

      // Refresh feedback list
      fetchFeedback();
    } catch (e) {
      console.error(e);
      setFeedbackMessage(
        e instanceof Error ? e.message : "Failed to submit feedback."
      );
    } finally {
      setSubmittingFeedback(false);
    }
  };

  useEffect(() => {
    if (activeTab === "past" && pastDecks.length === 0) {
      fetchPastDecks();
    }
  }, [activeTab, pastDecks.length]);

  useEffect(() => {
    if (activeTab === "feedback" && feedbackList.length === 0) {
      fetchFeedback();
    }
  }, [activeTab]);

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric",
    });
  };

  const SlidePreview = ({
    slide,
    index,
    onPresent,
  }: {
    slide: Slide;
    index: number;
    onPresent?: () => void;
  }) => (
    <div className="border rounded-lg p-3 bg-neutral-50 hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-2">
        <p className="font-semibold text-sm flex-1">{slide.title}</p>
        {onPresent && (
          <button
            onClick={onPresent}
            className="px-2 py-1 text-xs bg-blue-500 text-white rounded hover:bg-blue-600"
            title="Present this deck"
          >
            ▶
          </button>
        )}
      </div>

      <div className="h-[140px] mb-2">
        <SlideImage src={slide.image_url} alt={slide.title} index={index} />
      </div>

      <div className="text-xs mt-1 bg-white p-2 rounded-md border max-h-32 overflow-auto prose prose-sm">
        <ReactMarkdown>{slide.content_md}</ReactMarkdown>
      </div>
    </div>
  );

  if (presenterDeck) {
    return (
      <PresenterMode
        slides={presenterDeck.slides}
        deckTitle={presenterDeck.title}
        onClose={() => setPresenterDeck(null)}
      />
    );
  }

  return (
    <AppLayout>
      <div className="flex flex-1">
        <div className="flex flex-col w-80 bg-neutral-50 p-4">
          <h2 className="text-base font-medium mb-4">Slide Deck Generator</h2>

          <button
            onClick={() => setActiveTab("generator")}
            className={`px-4 py-2 rounded-lg mb-2 text-left text-sm ${activeTab === "generator" ? "bg-neutral-200" : ""
              }`}
          >
            Generate Slides
          </button>

          <button
            onClick={() => setActiveTab("past")}
            className={`px-4 py-2 rounded-lg mb-2 text-left text-sm ${activeTab === "past" ? "bg-neutral-200" : ""
              }`}
          >
            Past Slides
          </button>

          <button
            onClick={() => setActiveTab("feedback")}
            className={`px-4 py-2 rounded-lg text-left text-sm ${activeTab === "feedback" ? "bg-neutral-200" : ""
              }`}
          >
            Collect Feedback
          </button>
        </div>

        <div className="flex-1 p-4 max-w-[960px] mx-auto">
          {activeTab === "generator" ? (
            <>
              <h1 className="text-[32px] font-bold mb-6">
                Slide Deck Generator
              </h1>

              {errorMessage && (
                <div className="mb-4 p-3 rounded-lg border border-red-200 bg-red-50 text-sm text-red-700">
                  {errorMessage}
                </div>
              )}

              <div className="space-y-6 mb-6">
                <div>
                  <label className="font-medium">Deck Title</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    className="w-full h-14 px-4 mt-2 rounded-lg border"
                    placeholder="Enter slide deck title"
                    disabled={loading}
                  />
                </div>

                <div>
                  <label className="font-medium">Number of Slides</label>
                  <input
                    type="number"
                    value={numSlides}
                    min={1}
                    max={50}
                    onChange={(e) => setNumSlides(Number(e.target.value))}
                    className="w-full h-14 px-4 mt-2 rounded-lg border"
                    disabled={loading}
                  />
                </div>

                <div>
                  <label className="font-medium">Depth</label>
                  <select
                    value={depth}
                    onChange={(e) =>
                      setDepth(e.target.value as "summary" | "detailed")
                    }
                    className="w-full h-14 px-4 mt-2 rounded-lg border"
                    disabled={loading}
                  >
                    <option value="summary">Summary</option>
                    <option value="detailed">Detailed</option>
                  </select>
                </div>

                <div>
                  <label className="font-medium">Reference Documents</label>
                  <div className="mt-2 border rounded-lg max-h-40 overflow-auto">
                    {loadingDocs ? (
                      <p className="p-3 text-sm text-neutral-500">
                        Loading documents...
                      </p>
                    ) : docs.length === 0 ? (
                      <p className="p-3 text-sm text-neutral-500">
                        No documents found.
                      </p>
                    ) : (
                      docs.map((doc) => {
                        const checked = selectedDocIds.includes(doc.id);
                        return (
                          <label
                            key={doc.id}
                            className="flex items-center gap-2 px-3 py-2 border-b last:border-b-0 text-sm cursor-pointer hover:bg-neutral-50"
                          >
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() => {
                                setSelectedDocIds((prev) =>
                                  checked
                                    ? prev.filter((id) => id !== doc.id)
                                    : [...prev, doc.id]
                                );
                              }}
                            />
                            <span className="flex-1">{doc.title}</span>
                            {!doc.processed && (
                              <span className="text-[10px] px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-800">
                                Processing
                              </span>
                            )}
                          </label>
                        );
                      })
                    )}
                  </div>
                </div>
              </div>

              <button
                onClick={generateDeck}
                disabled={loading}
                className="px-4 py-2 bg-black text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? "Generating..." : "Start Slide Deck"}
              </button>

              {deckId && (
                <div className="mt-4 flex items-center gap-3 text-sm">
                  <span>
                    Deck ID: <strong>{deckId}</strong> · Status:{" "}
                    <strong>{status}</strong>
                  </span>
                  <button
                    onClick={refreshDeckStatus}
                    disabled={refreshingDeck}
                    className="px-3 py-1 text-xs rounded bg-neutral-200 hover:bg-neutral-300 disabled:opacity-50"
                  >
                    {refreshingDeck ? "Refreshing..." : "Refresh"}
                  </button>
                </div>
              )}

              {slides.length > 0 && (
                <>
                  <div className="flex justify-between items-center mt-8 mb-4">
                    <h2 className="text-[22px] font-bold">Generated Slides</h2>
                    <button
                      onClick={() => {
                        if (!deckId) return;
                        setPresenterDeck({
                          id: deckId,
                          title: title || "Untitled Deck",
                          status: status || "COMPLETED",
                          slides,
                          created_at: new Date().toISOString(),
                        });
                      }}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 text-sm"
                    >
                      🎬 Present Slides
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    {slides.map((slide, index) => (
                      <SlidePreview
                        key={slide.id}
                        slide={slide}
                        index={index}
                        onPresent={() => {
                          if (!deckId) return;
                          setPresenterDeck({
                            id: deckId,
                            title: title || "Untitled Deck",
                            status: status || "COMPLETED",
                            slides,
                            created_at: new Date().toISOString(),
                          });
                        }}
                      />
                    ))}
                  </div>
                </>
              )}
            </>
          ) : activeTab === "past" ? (
            <>
              <h1 className="text-[32px] font-bold mb-6">Past Slide Decks</h1>

              {loadingPast ? (
                <div className="flex items-center justify-center py-12">
                  <div className="w-12 h-12 border-4 border-neutral-300 border-t-black rounded-full animate-spin" />
                </div>
              ) : (
                <>
                  {!selectedDeck ? (
                    <div className="space-y-4">
                      {pastDecks.length === 0 ? (
                        <p className="text-neutral-600">
                          No past slide decks found.
                        </p>
                      ) : (
                        pastDecks.map((deck) => (
                          <div
                            key={deck.id}
                            className="border rounded-lg p-4 bg-neutral-50 hover:bg-neutral-100 cursor-pointer transition-colors"
                          >
                            <div className="flex justify-between items-start mb-2">
                              <div
                                onClick={() => setSelectedDeck(deck)}
                                className="flex-1"
                              >
                                <h3 className="text-lg font-semibold">
                                  {deck.title}
                                </h3>
                              </div>
                              <button
                                onClick={() => setPresenterDeck(deck)}
                                className="px-3 py-1 bg-blue-600 text-white rounded text-sm hover:bg-blue-700 ml-2"
                              >
                                🎬 Present
                              </button>
                              <span
                                className={`ml-2 px-2 py-1 text-xs rounded-full ${deck.status === "COMPLETED"
                                  ? "bg-green-100 text-green-700"
                                  : deck.status === "FAILED"
                                    ? "bg-red-100 text-red-700"
                                    : "bg-yellow-100 text-yellow-700"
                                  }`}
                              >
                                {deck.status}
                              </span>
                            </div>

                            <div
                              className="flex justify-between text-sm text-neutral-600"
                              onClick={() => setSelectedDeck(deck)}
                            >
                              <span>{deck.slides.length} slides</span>
                              <span>{formatDate(deck.created_at)}</span>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  ) : (
                    <>
                      <div className="flex justify-between items-center mb-6">
                        <div>
                          <button
                            onClick={() => setSelectedDeck(null)}
                            className="mb-4 text-sm text-neutral-600 hover:text-black"
                          >
                            ← Back to all decks
                          </button>

                          <div>
                            <h2 className="text-[22px] font-bold mb-2">
                              {selectedDeck.title}
                            </h2>
                            <div className="flex gap-4 text-sm text-neutral-600">
                              <span>{selectedDeck.slides.length} slides</span>
                              <span>{formatDate(selectedDeck.created_at)}</span>
                            </div>
                          </div>
                        </div>

                        <button
                          onClick={() => setPresenterDeck(selectedDeck)}
                          className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 h-fit"
                        >
                          🎬 Present Slides
                        </button>
                      </div>

                      <div className="grid grid-cols-2 gap-4">
                        {selectedDeck.slides
                          .sort((a, b) => a.position - b.position)
                          .map((slide, index) => (
                            <SlidePreview
                              key={slide.id}
                              slide={slide}
                              index={index}
                              onPresent={() => setPresenterDeck(selectedDeck)}
                            />
                          ))}
                      </div>
                    </>
                  )}
                </>
              )}
            </>
          ) : (
            <>
              <h1 className="text-[32px] font-bold mb-6">Student Feedback</h1>

              {feedbackMessage && (
                <div
                  className={`mb-4 p-3 rounded-lg border text-sm ${feedbackMessage.startsWith("✓")
                    ? "border-green-200 bg-green-50 text-green-700"
                    : "border-red-200 bg-red-50 text-red-700"
                    }`}
                >
                  {feedbackMessage}
                </div>
              )}

              {/* Submit Feedback Form */}
              <div className="bg-neutral-50 rounded-lg p-6 mb-8 border">
                <h3 className="text-lg font-bold mb-3">
                  How was the presentation?
                </h3>

                <div className="flex gap-3 mb-6">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <label
                      key={star}
                      className={`border px-4 h-11 flex items-center rounded-lg cursor-pointer transition-colors ${feedbackRating === star
                        ? "bg-blue-500 text-white border-blue-500"
                        : "hover:bg-neutral-100"
                        }`}
                    >
                      <input
                        type="radio"
                        name="rating"
                        value={star}
                        checked={feedbackRating === star}
                        onChange={() => setFeedbackRating(star)}
                        className="invisible absolute"
                        disabled={submittingFeedback}
                      />
                      {star} Star{star > 1 ? "s" : ""}
                    </label>
                  ))}
                </div>

                <h3 className="text-lg font-bold mb-2">Comments</h3>

                <textarea
                  value={feedbackComment}
                  onChange={(e) => setFeedbackComment(e.target.value)}
                  className="w-full min-h-[120px] border p-3 rounded-lg"
                  placeholder="Add your comments (optional)"
                  disabled={submittingFeedback}
                ></textarea>

                <button
                  onClick={submitFeedback}
                  disabled={submittingFeedback || !feedbackRating}
                  className="mt-4 px-4 py-2 bg-black text-white rounded-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submittingFeedback ? "Submitting..." : "Submit Feedback"}
                </button>
              </div>

              {/* Feedback List */}
              <div>
                <div className="flex justify-between items-center mb-4">
                  <h2 className="text-[22px] font-bold">All Feedback</h2>
                  <button
                    onClick={fetchFeedback}
                    disabled={loadingFeedback}
                    className="px-3 py-1 text-sm bg-neutral-200 rounded hover:bg-neutral-300 disabled:opacity-50"
                  >
                    {loadingFeedback ? "Loading..." : "Refresh"}
                  </button>
                </div>

                {loadingFeedback ? (
                  <div className="flex items-center justify-center py-12">
                    <div className="w-12 h-12 border-4 border-neutral-300 border-t-black rounded-full animate-spin" />
                  </div>
                ) : feedbackList.length === 0 ? (
                  <p className="text-neutral-600 text-center py-8">
                    No feedback yet. Be the first to share your thoughts!
                  </p>
                ) : (
                  <div className="space-y-4">
                    {feedbackList.map((feedback) => (
                      <div
                        key={feedback.id}
                        className="border rounded-lg p-4 bg-white hover:shadow-sm transition-shadow"
                      >
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex items-center gap-2">
                            <div className="flex">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <span
                                  key={star}
                                  className={`text-lg ${star <= feedback.rating
                                    ? "text-yellow-500"
                                    : "text-neutral-300"
                                    }`}
                                >
                                  ★
                                </span>
                              ))}
                            </div>
                            <span className="text-sm font-semibold">
                              {feedback.rating}/5
                            </span>
                          </div>
                          <span className="text-xs text-neutral-500">
                            {formatDate(feedback.created_at)}
                          </span>
                        </div>

                        {feedback.comment && (
                          <p className="text-sm text-neutral-700 mt-2">
                            {feedback.comment}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </AppLayout>
  );
}
