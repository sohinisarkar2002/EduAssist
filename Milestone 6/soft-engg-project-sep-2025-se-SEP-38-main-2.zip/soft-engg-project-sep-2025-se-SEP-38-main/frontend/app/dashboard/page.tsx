"use client";

import Link from "next/link";
import AppLayout from "@/components/AppLayout";
import { useEffect, useState } from "react";

export default function Page() {
  const API_BASE = process.env.NEXT_PUBLIC_API_URL;
  const token =
    typeof window !== "undefined" ? localStorage.getItem("access_token") : null;

  // ----------- Dashboard state -----------
  const [stats, setStats] = useState({
    assessments: 0,
    studyGuides: 0,
    conversations: 0,
    workflows: 0,
    slideDecks: 0,
    timeSavedHours: 0,
  });

  const [loading, setLoading] = useState(true);

  // ----------- Fetch All Dashboard Metrics -----------
  const fetchDashboardData = async () => {
    try {
      const headers = token
        ? { Authorization: `Bearer ${token}` }
        : {};

      // Backend calls (lightweight endpoints preferred)
      const [
        assessmentsRes,
        guidesRes,
        conversationsRes,
        workflowsRes,
        slideDeckRes,
      ] = await Promise.all([
        fetch(`${API_BASE}/assessments`,
          //{ headers }
        ),
        fetch(`${API_BASE}/study-guides`,
          //{ headers }
        )
        ,
        fetch(`${API_BASE}/knowledge/conversations`,
          // { headers }
        )
        ,
        fetch(`${API_BASE}/workflow`,
          // { headers }

        ),
        fetch(`${API_BASE}/slide-decks`,
          // { headers }

        ),
      ]);

      const [
        assessments,
        guides,
        conversations,
        workflows,
        slideDecks,
      ] = await Promise.all([
        assessmentsRes.json(),
        guidesRes.json(),
        conversationsRes.json(),
        workflowsRes.json(),
        slideDeckRes.json(),
      ]);

      setStats({
        assessments: assessments?.length || 0,
        studyGuides: guides?.length || 0,
        conversations: conversations?.length || 0,
        workflows: workflows?.length || 0,
        slideDecks: slideDecks?.length || 0,

        // AI time-saved estimation
        timeSavedHours:
          (assessments?.length || 0) * 0.5 +
          (guides?.length || 0) * 0.75 +
          (slideDecks?.length || 0) * 1.0 +
          (workflows?.length || 0) * 0.25,
      });
    } catch (err) {
      console.error("Dashboard load error:", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  // ----------- Tool Cards -----------
  const tools = [
    {
      title: "Knowledge Assistant",
      description: "Get instant answers to student queries.",
      image: "https://api.builder.io/api/v1/image/assets/TEMP/ff8ac35bba17610bbaef00d2a1a2673a74f8a185?width=332",
      link: "/features/knowledge-assistant",
      stat: stats.conversations,
    },
    {
      title: "Study Guide Generator",
      description: "Generate comprehensive study guides.",
      image: "https://api.builder.io/api/v1/image/assets/TEMP/475baaa591c5daa5278ef3b2a42ec72f9890ed27?width=332",
      link: "/features/study-guide-generator",
      stat: stats.studyGuides,
    },
    {
      title: "Admin Workflow Agent",
      description: "Automate administrative tasks.",
      image: "https://api.builder.io/api/v1/image/assets/TEMP/7447fa5ac6a790380b255201fbd9710106627d37?width=332",
      link: "/features/admin-workflow",
      stat: stats.workflows,
    },
    {
      title: "Assessment Generator",
      description: "Create assessments quickly.",
      image: "https://api.builder.io/api/v1/image/assets/TEMP/7d3a98010bb014cd3f015ef22832921320f5b20b?width=332",
      link: "/features/assessment-generator",
      stat: stats.assessments,
    },
    {
      title: "Slide Deck Creator",
      description: "Design engaging slide decks.",
      image: "https://api.builder.io/api/v1/image/assets/TEMP/4f0abf590a8fb876c4c7303fe90ae9ea19393b50?width=332",
      link: "/features/slide-deck-generator",
      stat: stats.slideDecks,
    },
  ];


  return (
    <AppLayout>
      <div className="max-w-[960px] mx-auto py-4 px-4 sm:px-6">
        {/* Header */}
        <div className="p-4 mb-4">
          <h1 className="text-[32px] font-bold text-[#0D141C] leading-[40px]">
            Dashboard
          </h1>
        </div>

        {/* AI Tools */}
        <div className="py-5 px-4">
          <h2 className="text-[22px] font-bold text-[#0D141C] mb-3">AI Tools</h2>
        </div>

        {/* Tools Grid */}
        <div className="p-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {tools.map((tool, index) => (
              <Link
                key={index}
                href={tool.link}
                className="flex flex-col gap-3 pb-3 group hover:opacity-80 transition-opacity"
              >
                <img
                  src={tool.image}
                  alt={tool.title}
                  className="w-full aspect-square object-cover rounded-lg"
                />

                <div className="flex flex-col gap-1">
                  <h3 className="text-base font-medium text-[#0D141C]">
                    {tool.title}
                  </h3>
                  <p className="text-sm text-[#4D7399]">{tool.description}</p>

                  {/* Dynamic usage count */}
                  {!loading && (
                    <p className="text-xs text-[#4D7399]">
                      Used <strong>{tool.stat}</strong> times
                    </p>
                  )}
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Analytics Section */}
        <div className="py-5 px-4 mt-6">
          <h2 className="text-[22px] font-bold text-[#0D141C] mb-3">Analytics</h2>
        </div>

        <div className="p-4">
          <div className="flex flex-wrap gap-4">
            {/* Time Saved */}
            <div className="flex-1 min-w-[158px] p-6 rounded-lg border border-[#CFDBE8] flex flex-col gap-2">
              <div className="text-base font-medium text-[#0D141C]">
                Time Saved
              </div>
              <div className="text-2xl font-bold text-[#0D141C]">
                {loading ? "…" : `${stats.timeSavedHours.toFixed(1)} hrs`}
              </div>
              <div className="text-base font-medium text-[#088738]">
                + AI Productivity
              </div>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}

