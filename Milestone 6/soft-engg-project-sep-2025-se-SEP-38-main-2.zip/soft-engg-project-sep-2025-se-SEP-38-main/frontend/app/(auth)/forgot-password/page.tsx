"use client";

import { useState } from "react";
import Link from "next/link";
import { Eye, EyeOff, CheckCircle } from "lucide-react";

type Step = "email" | "reset" | "success";

export default function ForgotPassword() {
  const API_BASE = "http://localhost:8000";

  const [step, setStep] = useState<Step>("email");

  const [email, setEmail] = useState("");
  const [token, setToken] = useState("");

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [errorMsg, setErrorMsg] = useState("");
  const [loading, setLoading] = useState(false);

  /* -------------------------
     STEP 1: REQUEST RESET TOKEN
     ------------------------- */
  const handleEmailSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    try {
      setLoading(true);

      const res = await fetch(
        `${API_BASE}/auth/password-reset-request?email=${encodeURIComponent(email)}`,
        {
          method: "POST",
        }
      );

      const data = await res.json();

      if (!res.ok) {
        setErrorMsg(data?.detail || "Unable to send password reset link.");
        return;
      }

      setStep("reset");
    } catch (err) {
      setErrorMsg("Server error. Try again later.");
    } finally {
      setLoading(false);
    }
  };

  /* -------------------------
     STEP 2: RESET PASSWORD
     ------------------------- */
  const handleResetSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");

    if (password !== confirmPassword) {
      setErrorMsg("Passwords do not match.");
      return;
    }

    try {
      setLoading(true);

      const url = `${API_BASE}/auth/reset-password?token=${encodeURIComponent(
        token
      )}&new_password=${encodeURIComponent(password)}`;

      const res = await fetch(url, { method: "POST" });

      const data = await res.json();

      if (!res.ok) {
        setErrorMsg(data?.detail || "Failed to reset password.");
        return;
      }

      setStep("success");
    } catch (err) {
      setErrorMsg("Server error. Try again later.");
    } finally {
      setLoading(false);
    }
  };

  /* ==========================
     UI RENDERING BELOW
     ========================== */

  return (
    <div className="relative flex min-h-screen flex-col bg-slate-50">
      <header className="flex items-center justify-between border-b px-10 py-3">
        <Link href="/" className="flex items-center gap-4 text-[#0d141b]">
          <h2 className="text-lg font-bold">EduAssist</h2>
        </Link>
      </header>

      <div className="flex flex-1 justify-center px-6 py-5 gap-12">
        <div className="flex flex-col w-full max-w-[480px] justify-center">
          {errorMsg && (
            <div className="bg-red-100 border border-red-300 text-red-600 px-4 py-2 rounded mb-4">
              {errorMsg}
            </div>
          )}

          {/* STEP 1: EMAIL INPUT */}
          {step === "email" && (
            <>
              <h1 className="text-[28px] font-bold mb-2">Reset your password</h1>
              <p className="text-sm text-[#4c739a] mb-6">
                Enter your email address to receive a reset link.
              </p>

              <form onSubmit={handleEmailSubmit} className="space-y-6">
                <div>
                  <label className="block font-medium mb-1">Email</label>
                  <input
                    type="email"
                    value={email}
                    required
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border"
                    placeholder="Enter your email"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full px-4 py-3 rounded-lg bg-blue-600 text-white font-bold"
                >
                  {loading ? "Sending..." : "Send Reset Link"}
                </button>
              </form>
            </>
          )}

          {/* STEP 2: ENTER TOKEN + NEW PASSWORD */}
          {step === "reset" && (
            <>
              <h1 className="text-[28px] font-bold mb-3">Reset Password</h1>

              <form onSubmit={handleResetSubmit} className="space-y-6">
                {/* TOKEN */}
                <div>
                  <label className="block font-medium mb-1">Reset Token</label>
                  <input
                    type="text"
                    value={token}
                    required
                    onChange={(e) => setToken(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg border"
                    placeholder="Enter the token from your email"
                  />
                </div>

                {/* PASSWORD */}
                <div>
                  <label className="block font-medium mb-1">New Password</label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      required
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border pr-10"
                      placeholder="Enter new password"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                    >
                      {showPassword ? <EyeOff /> : <Eye />}
                    </button>
                  </div>
                </div>

                {/* CONFIRM PASSWORD */}
                <div>
                  <label className="block font-medium mb-1">Confirm Password</label>
                  <div className="relative">
                    <input
                      type={showConfirmPassword ? "text" : "password"}
                      value={confirmPassword}
                      required
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      className="w-full px-4 py-3 rounded-lg border pr-10"
                      placeholder="Confirm password"
                    />
                    <button
                      type="button"
                      onClick={() =>
                        setShowConfirmPassword(!showConfirmPassword)
                      }
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                    >
                      {showConfirmPassword ? <EyeOff /> : <Eye />}
                    </button>
                  </div>

                  {password !== confirmPassword && confirmPassword && (
                    <p className="text-red-500 text-xs mt-1">
                      Passwords do not match
                    </p>
                  )}
                </div>

                <button
                  type="submit"
                  disabled={loading || password !== confirmPassword}
                  className="w-full px-4 py-3 rounded-lg bg-blue-600 text-white font-bold disabled:opacity-50"
                >
                  {loading ? "Resetting..." : "Reset Password"}
                </button>
              </form>
            </>
          )}

          {/* STEP 3: SUCCESS */}
          {step === "success" && (
            <div className="text-center">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />

              <h1 className="text-[28px] font-bold mb-2">
                Password reset successful
              </h1>

              <p className="text-[#4c739a] mb-6">
                Your password has been updated. You can now log in.
              </p>

              <Link
                href="/login"
                className="w-full px-4 py-3 rounded-lg bg-blue-600 text-white font-bold block"
              >
                Back to Login
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}


