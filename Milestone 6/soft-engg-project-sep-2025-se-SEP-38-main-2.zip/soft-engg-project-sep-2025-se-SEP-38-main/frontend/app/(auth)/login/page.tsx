"use client";

import { useState } from "react";
import Link from "next/link";
import { Eye, EyeOff } from "lucide-react";
import { useRouter } from "next/navigation";

export default function Login() {
  const router = useRouter();
  const API_BASE = "http://localhost:8000";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleLogin = async () => {
    setErrorMsg("");

    if (!email || !password) {
      setErrorMsg("Please enter both email and password.");
      return;
    }

    try {
      setLoading(true);

      // 🔥 REQUIRED FORMAT FOR FastAPI OAuth2PasswordRequestForm
      const formBody = new URLSearchParams();
      formBody.append("grant_type", "password");
      formBody.append("username", email); // 👈 FastAPI expects username
      formBody.append("password", password);
      formBody.append("scope", "");
      formBody.append("client_id", "");
      formBody.append("client_secret", "");

      const res = await fetch(`${API_BASE}/auth/login`, {
        method: "POST",
        headers: { 
          "Content-Type": "application/x-www-form-urlencoded"
        },
        body: formBody.toString(),
      });

      const data = await res.json();

      if (!res.ok) {
        // 422 validation or invalid credentials
        if (Array.isArray(data?.detail)) {
          setErrorMsg(data.detail[0]?.msg || "Login failed.");
        } else {
          setErrorMsg(data?.detail || "Login failed.");
        }
        return;
      }

      // 200 SUCCESS
      if (data?.access_token) {
        localStorage.setItem("access_token", data.access_token);
      }

      router.push("/dashboard");

    } catch (err) {
      console.error("Login failed:", err);
      setErrorMsg("Server error. Try again later.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-screen w-full flex-col bg-neutral-50 overflow-x-hidden">
      <header className="flex items-center justify-between border-b border-[#ededed] px-10 py-3">
        <Link href="/" className="flex items-center gap-4 text-[#141414]">
          <div className="size-4">
            <svg viewBox="0 0 48 48" fill="none">
              <g clipPath="url(#clip0)">
                <path d="M42.1739 20.1739..." fill="currentColor" />
              </g>
            </svg>
          </div>
          <h2 className="text-[#141414] text-lg font-bold">EduAssist</h2>
        </Link>
      </header>

      <div className="flex flex-1 justify-center px-6 py-5 gap-12">
        <div className="flex flex-col w-full max-w-[480px] justify-center">
          <h1 className="text-[32px] font-bold mb-2">Sign in to your account</h1>
          <p className="text-neutral-500 mb-8">Welcome back! Please login to continue.</p>

          {errorMsg && (
            <div className="mb-4 text-red-600 text-sm font-medium bg-red-100 border border-red-200 px-3 py-2 rounded">
              {errorMsg}
            </div>
          )}

          <div className="mb-6">
            <label className="block text-base font-medium pb-2">Email</label>
            <input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 rounded-lg border bg-neutral-50 focus:ring-2 focus:ring-[#141414] text-base"
            />
          </div>

          <div className="mb-6">
            <label className="block text-base font-medium pb-2">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border bg-neutral-50 text-base pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-500"
              >
                {showPassword ? <EyeOff /> : <Eye />}
              </button>
            </div>
          </div>

          <button
            onClick={handleLogin}
            disabled={loading}
            className="w-full px-4 py-3 rounded-lg bg-[#141414] text-white font-bold hover:bg-[#141414]/90"
          >
            {loading ? "Logging in..." : "Login"}
          </button>

          <Link
            href="/signup"
            className="w-full px-4 py-3 rounded-lg bg-[#ededed] text-[#141414] font-bold mt-3 hover:bg-[#ededed]/80 text-center"
          >
            Take me to Sign up
          </Link>
        </div>
      </div>

      <footer className="text-center text-neutral-500 text-sm py-6 border-t border-[#ededed]">
        © 2025 EduAssist. All rights reserved.
      </footer>
    </div>
  );
}


