"use client";

import { useState } from "react";
import Link from "next/link";
import { Eye, EyeOff } from "lucide-react";
import { useRouter } from "next/navigation";

export default function Signup() {
  const router = useRouter();

  const API_BASE = "http://localhost:8000";

  const [formData, setFormData] = useState({
    full_name: "",
    email: "",
    username: "",
    password: "",
  });

  const [showPassword, setShowPassword] = useState(false);
  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSignup = async () => {
    setErrorMsg("");

    if (!agreedToTerms) {
      setErrorMsg("You must agree to the Terms & Conditions.");
      return;
    }

    if (!formData.full_name || !formData.email || !formData.username || !formData.password) {
      setErrorMsg("Please fill all required fields.");
      return;
    }

    try {
      setLoading(true);

      const res = await fetch(`${API_BASE}/auth/register`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: formData.email,
          username: formData.username,
          full_name: formData.full_name,
          password: formData.password,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        if (res.status === 422 && data.detail) {
          // show validation errors from backend
          const msg = data.detail
            .map((d: any) => `${d.loc.join(" → ")}: ${d.msg}`)
            .join("\n");
          setErrorMsg(msg);
          return;
        }

        setErrorMsg(data?.detail || "Signup failed. Try again.");
        return;
      }

      // Successful signup (200)
      router.push("/login");
    } catch (err) {
      console.error(err);
      setErrorMsg("Server error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="relative flex min-h-screen w-full flex-col bg-slate-50 overflow-x-hidden">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-[#e7edf3] px-10 py-3">
        <Link href="/" className="flex items-center gap-4 text-[#0d141b]">
          <div className="size-4">
            <svg viewBox="0 0 48 48" fill="none">
              <path d="M42.17 20.17L27.82 5.83..." fill="currentColor" />
            </svg>
          </div>
          <h2 className="text-lg font-bold">EduAssist</h2>
        </Link>
      </header>

      {/* Main */}
      <div className="flex flex-1 justify-center px-6 py-5 gap-12">
        {/* Form */}
        <div className="flex flex-col w-full max-w-[480px] justify-center">
          <h1 className="text-[28px] font-bold text-center mb-8">
            Create your account
          </h1>

          {errorMsg && (
            <div className="mb-4 whitespace-pre-line text-red-600 text-sm font-medium bg-red-100 border border-red-200 px-3 py-2 rounded">
              {errorMsg}
            </div>
          )}

          {/* Full Name */}
          <Field
            label="Full Name"
            name="full_name"
            placeholder="Enter your full name"
            value={formData.full_name}
            onChange={handleChange}
          />

          {/* Username */}
          <Field
            label="Username"
            name="username"
            placeholder="Choose a username"
            value={formData.username}
            onChange={handleChange}
          />

          {/* Email */}
          <Field
            label="Email"
            name="email"
            type="email"
            placeholder="Enter your email"
            value={formData.email}
            onChange={handleChange}
          />

          {/* Password */}
          <div className="mb-6">
            <label className="text-sm font-medium text-[#0d141b] mb-2 block">
              Password
            </label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                name="password"
                placeholder="Enter your password"
                value={formData.password}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg border bg-slate-50 pr-10"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#4c739a]"
              >
                {showPassword ? <EyeOff /> : <Eye />}
              </button>
            </div>
          </div>

          {/* Terms */}
          <div className="mb-6 flex items-start gap-2">
            <input
              type="checkbox"
              checked={agreedToTerms}
              onChange={(e) => setAgreedToTerms(e.target.checked)}
              className="mt-1 w-4 h-4"
            />
            <label className="text-sm text-[#4c739a]">
              I agree to the{" "}
              <span className="font-medium text-[#0d141b]">
                Terms & Conditions
              </span>{" "}
              and{" "}
              <span className="font-medium text-[#0d141b]">Privacy Policy</span>
            </label>
          </div>

          {/* Signup Button */}
          <button
            onClick={handleSignup}
            disabled={loading}
            className="w-full py-3 rounded-lg bg-[#1380ec] text-white font-bold hover:bg-[#1380ec]/90"
          >
            {loading ? "Creating account..." : "Create Account"}
          </button>

          <p className="text-center text-sm text-[#4c739a] mt-4">
            Already have an account?{" "}
            <Link href="/login" className="underline">
              Login
            </Link>
          </p>
        </div>

        {/* Right Illustration */}
        <Illustration />
      </div>

      <footer className="text-center text-sm text-[#4c739a] py-6 border-t border-[#e7edf3]">
        © 2025 EduAssist. All rights reserved.
      </footer>
    </div>
  );
}

function Field({ label, ...props }: any) {
  return (
    <div className="mb-6">
      <label className="text-sm font-medium text-[#0d141b] mb-2 block">
        {label}
      </label>
      <input {...props} className="w-full px-4 py-3 rounded-lg border bg-slate-50" />
    </div>
  );
}

function Illustration() {
  return (
    <div className="hidden lg:flex flex-col w-[400px] justify-center">
      <div className="rounded-lg overflow-hidden shadow-lg bg-slate-50 p-4">
        <div
          className="w-full aspect-square bg-center bg-cover rounded-lg"
          style={{
            backgroundImage:
              'url("https://lh3.googleusercontent.com/aida-public/...")',
          }}
        />
      </div>
      <p className="text-[#4c739a] text-sm text-center mt-6">
        Join thousands of educators and TAs using EduAssist to enhance their
        teaching
      </p>
    </div>
  );
}


