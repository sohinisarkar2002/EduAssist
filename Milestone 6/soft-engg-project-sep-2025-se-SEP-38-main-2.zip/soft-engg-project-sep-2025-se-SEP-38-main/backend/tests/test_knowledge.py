"""
Tests for Knowledge Assistant API
"""
import pytest
from httpx import AsyncClient
from io import BytesIO


@pytest.mark.asyncio
async def test_upload_document(client: AsyncClient, auth_token, test_course):
    """Test document upload"""
    # Create a simple text file
    file_content = b"This is a test document for the course."
    
    response = await client.post("/knowledge/documents",
        headers={"Authorization": f"Bearer {auth_token}"},
        files={"file": ("test.txt", BytesIO(file_content), "text/plain")},
        data={"title": "Test Document", "course_id": test_course.id}
    )
    
    assert response.status_code == 201
    data = response.json()
    assert data["title"] == "Test Document"
    assert data["course_id"] == test_course.id


@pytest.mark.asyncio
async def test_list_documents(client: AsyncClient, auth_token):
    """Test listing documents"""
    response = await client.get("/knowledge/documents",
        headers={"Authorization": f"Bearer {auth_token}"}
    )
    assert response.status_code == 200


@pytest.mark.asyncio
async def test_create_conversation(client: AsyncClient, auth_token, test_course):
    """Test conversation creation"""
    response = await client.post("/knowledge/conversations",
        headers={"Authorization": f"Bearer {auth_token}"},
        json={"course_id": test_course.id}
    )
    assert response.status_code == 201
    data = response.json()
    assert data["course_id"] == test_course.id
    assert data["status"] == "ACTIVE"


@pytest.mark.asyncio
async def test_list_conversations(client: AsyncClient, auth_token, test_course):
    """Test listing conversations"""
    response = await client.get("/knowledge/conversations",
        headers={"Authorization": f"Bearer {auth_token}"},
        params={"course_id": test_course.id}
    )

    assert response.status_code == 200
    data = response.json()
    assert "conversations" in data
    assert isinstance(data["conversations"], list)


@pytest.mark.asyncio
async def test_get_conversation(client: AsyncClient, auth_token, test_course):
    """Test getting conversation by ID"""
    # First create one
    create_response = await client.post("/knowledge/conversations",
        headers={"Authorization": f"Bearer {auth_token}"},
        json={"course_id": test_course.id}
    )
    conversation_id = create_response.json()["id"]

    # Get it
    response = await client.get(f"/knowledge/conversations/{conversation_id}",
        headers={"Authorization": f"Bearer {auth_token}"}
    )

    assert response.status_code == 200
    data = response.json()
    assert data["id"] == conversation_id


@pytest.mark.asyncio
async def test_delete_conversation(client: AsyncClient, auth_token, test_course):
    """Test deleting conversation"""
    # First create one
    create_response = await client.post("/knowledge/conversations",
        headers={"Authorization": f"Bearer {auth_token}"},
        json={"course_id": test_course.id}
    )
    conversation_id = create_response.json()["id"]

    # Delete it
    response = await client.delete(f"/knowledge/conversations/{conversation_id}",
        headers={"Authorization": f"Bearer {auth_token}"}
    )

    assert response.status_code == 204


@pytest.mark.asyncio
async def test_unauthorized_access(client: AsyncClient):
    """Test accessing without authentication"""
    response = await client.get("/knowledge/conversations")
    assert response.status_code == 401


@pytest.mark.asyncio
async def test_chat_query(client: AsyncClient, auth_token, test_course):
    """Test chat query"""
    response = await client.post("/knowledge/chat",
        headers={"Authorization": f"Bearer {auth_token}"},
        json={
            "query": "What is Python?",
            "course_id": test_course.id
        }
    )
    assert response.status_code == 200
    data = response.json()
    assert "message" in data
    assert "confidence_score" in data
    assert "should_escalate" in data
