import pytest
from httpx import AsyncClient


@pytest.mark.asyncio
async def test_submit_workflow(client: AsyncClient, auth_token):
    payload = {
        "title": "Extension Request for Assignment 2",
        "description": "My laptop failed the night before deadline.",
        "request_type": "extension"
    }
    response = await client.post("/workflow/workflow-requests/",
        headers={"Authorization": f"Bearer {auth_token}"}, json=payload)
    
    assert response.status_code == 200
    assert response.json()["title"] == "Extension Request for Assignment 2"
