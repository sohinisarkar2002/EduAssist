"""
Pytest Configuration and Fixtures
"""
import pytest
import asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from typing import AsyncGenerator

from app.main import app
from app.database import Base, get_db
from app.config import settings
from app import crud, schemas

# Test database URL (use an in-memory SQLite DB shared across connections)
TEST_DATABASE_URL = settings.TEST_DATABASE_URL

# Create test engine
test_engine = create_async_engine(TEST_DATABASE_URL, echo=False)
TestAsyncSessionLocal = async_sessionmaker(
    test_engine, class_=AsyncSession, expire_on_commit=False
)


@pytest.fixture(scope="session")
def event_loop():
    """Create event loop for async tests"""
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()


@pytest.fixture(scope="function", autouse=True)
async def setup_test_db():
    async with test_engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)
        await conn.run_sync(Base.metadata.create_all)
    yield


# Override FastAPI's DB dependency
async def override_get_db() -> AsyncGenerator[AsyncSession, None]:
    """Override database dependency for testing"""
    async with TestAsyncSessionLocal() as session:
        yield session


app.dependency_overrides[get_db] = override_get_db


@pytest.fixture(scope="function")
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    """Database session for tests"""
    async with TestAsyncSessionLocal() as session:
        yield session


# HTTP client
@pytest.fixture(scope="function")
async def client() -> AsyncGenerator[AsyncClient, None]:
    """HTTP client for API testing"""
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


@pytest.fixture(scope="function")
async def test_user(db_session: AsyncSession):
    """Create a test user"""
    user = await crud.create_user(
        db=db_session,
        user=schemas.UserCreate(
            email="test@example.com",
            username="testuser",
            password="testpass123",
            full_name="Test User"
        )
    )
    return user


@pytest.fixture(scope="function")
async def test_course(db_session: AsyncSession):
    """Create a test course"""
    course = await crud.create_course(
        db=db_session,
        course=schemas.CourseCreate(
            code="CS101",
            name="Introduction to Computer Science",
            description="Test course"
        )
    )
    return course


# Auth token
@pytest.fixture(scope="function")
async def auth_token(client: AsyncClient, db_session: AsyncSession):
    """
    Creates a test user and returns a valid auth token.
    """
    # Create the user in the database
    await crud.create_user(
        db=db_session,
        user=schemas.UserCreate(
            email="testauth@example.com",
            username="testauth",
            password="testpass123",
            full_name="Auth Test User"
        )
    )

    # Login and get the auth token
    response = await client.post("/auth/login",
        data={"username": "testauth", "password": "testpass123"}
    )
    assert response.status_code == 200
    data = response.json()
    assert "access_token" in data
    return data["access_token"]


@pytest.mark.asyncio
async def test_health_check(client: AsyncClient):
    """Test health check endpoint"""
    response = await client.get("/")
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "healthy"


@pytest.mark.asyncio
async def test_create_course(client: AsyncClient):
    """Test course creation"""
    response = await client.post("/courses",
        json={
            "code": "CS102",
            "name": "Data Structures",
            "description": "Learn about data structures"
        }
    )
    assert response.status_code == 201
    data = response.json()
    assert data["code"] == "CS102"


@pytest.mark.asyncio
async def test_list_courses(client: AsyncClient, test_course):
    """Test listing courses"""
    response = await client.get("/courses")
    assert response.status_code == 200
    data = response.json()
    assert len(data) > 0
