"""
EduAssist FastAPI Application
"""
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import datetime, timezone

from .config import settings
from . import crud, schemas
from .database import init_db, get_db
from .routers import auth, knowledge, study_guide, feedback
from .routers import workflow_agent, assessment, slide_deck

# Lifecycle events
@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup and shutdown events"""
    # Startup
    print("🚀 Starting EduAssist API...")
    await init_db()
    print("✅ Database initialized")
    yield
    # Shutdown
    print("👋 Shutting down EduAssist API...")


# Create FastAPI app
app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="AI-Powered Teaching Assistant Platform - Knowledge Assistant Feature",
    lifespan=lifespan
)


# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Include routers
app.include_router(auth.router, tags=["Authentication"])
app.include_router(knowledge.router, tags=["Knowledge Assistant"])
app.include_router(study_guide.router, tags=["Study Guide Generator"])
app.include_router(workflow_agent.router, tags=["Workflow Automation"])
app.include_router(assessment.router, tags=["Assessment Generator"])
app.include_router(slide_deck.router, tags=["Slide Deck Generator"])
app.include_router(feedback.router, tags=["Feedback"])


# ============ Health Check ============

@app.get("/")
async def root():
    """Health check"""
    return {
        "app": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "status": "healthy"
    }


@app.get("/health")
async def health_check():
    """Detailed health check"""
    return {
        "status": "healthy",
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "services": {
            "api": "operational",
            "database": "operational",
            "rag": "operational"
        }
    }


# ============ Course Endpoints ============

@app.post("/courses", response_model=schemas.CourseResponse, status_code=201)
async def create_course(
    course: schemas.CourseCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new course"""
    return await crud.create_course(db=db, course=course)


@app.get("/courses", response_model=list[schemas.CourseResponse])
async def list_courses(db: AsyncSession = Depends(get_db)):
    """List all courses"""
    return await crud.get_courses(db=db)
