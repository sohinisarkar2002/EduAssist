"""Slide Deck Generator API Endpoints"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from typing import List, Optional

from app.database import get_db
from app.dependencies import get_current_user
from app.models import User
from app.schemas import SlideDeckCreate, SlideDeckOut, SlideOut
from app.crud import get_slide_deck, list_slide_decks, update_slide_content
from app.services.slide_deck_service import create_slide_deck
from app.services.rag_service import extract_text_from_documents

router = APIRouter(prefix="/slide-decks", tags=["Slide Deck Generator"])


@router.post("/", response_model=dict)
async def start_slide_deck(
    body: SlideDeckCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Generate slide deck from uploaded docs. Returns deck_id (status PENDING/COMPLETE)
    """
    ref_texts = await extract_text_from_documents(body.reference_document_ids, db)
    deck_id = await create_slide_deck(db, current_user.id, body.title, body.controls, ref_texts)
    return {"deck_id": deck_id}

@router.get("/{deck_id}", response_model=SlideDeckOut)
async def get_deck(
    deck_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    deck = await get_slide_deck(db, deck_id, current_user.id)
    if not deck:
        raise HTTPException(status_code=404, detail="Slide Deck not found")
    return deck

@router.get("/", response_model=List[SlideDeckOut])
async def list_decks(
    status: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    decks = await list_slide_decks(db, current_user.id, status)
    return decks

@router.put("/{deck_id}/slide/{slide_id}", response_model=SlideOut)
async def update_slide(
    slide_id: int,
    content_md: str,
    notes_md: Optional[str] = None,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    updated = await update_slide_content(db, slide_id, current_user.id, content_md, notes_md)
    if not updated:
        raise HTTPException(status_code=404, detail="Not found or permission denied")
    return updated
