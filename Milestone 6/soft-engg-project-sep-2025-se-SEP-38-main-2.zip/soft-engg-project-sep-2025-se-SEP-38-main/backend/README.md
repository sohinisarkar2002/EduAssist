# Getting Started

## Prerequisites

1. Python 3.12+
2. [`uv`](https://docs.astral.sh/uv/#installation) - Python project manager

## Installation

1. Navigate to the backend directory:
    ```bash
    cd backend
    ```

2. Setup environment variables:
    ```bash
    cp .env.example .env
    ```

3. Database setup:
    - Create a free database on [Neon](https://neon.tech/)
    - Update the database connection URL in the `.env` file
    ```bash
    DATABASE_URL=postgresql://<username>:<password>@<host>:<port>/<database>
    ```

4. Generate and add keys to `.env` file:
    - Obtain a Google Gemini API Key from [Google AI Studio](https://aistudio.google.com/app/api-keys)
    - Obtain a free SendGrid API Key from [SendGrid](https://sendgrid.com/en-us/free)
    - Generate a Secret Key with:
      ```bash
      openssl rand -hex 32
      ``` 
5. Set the FRONTEND_URL in the `.env` file to [http://localhost:3000](http://localhost:3000)

6. Start the FastAPI development server:
    ```bash
    source launch.sh
    ```

7. Access the API documentation at [http://localhost:8000/docs](http://localhost:8000/docs)
